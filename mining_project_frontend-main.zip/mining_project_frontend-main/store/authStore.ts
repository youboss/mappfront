import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import apiClient from '@/lib/api';

interface User {
    id: string;
    name: string;
    email: string;
    roles?: { id: string; name: string }[];
    status: string;
    avatar?: string;
    created_at?: string;
}

interface AuthState {
    user: User | null;
    isAuthenticated: boolean;
    setAuth: (user: User) => void;
    updateUser: (user: User) => void;
    logout: () => void;
    isAdmin: () => boolean;
}

export const useAuthStore = create<AuthState>((set, get) => ({
    user: null,
    isAuthenticated: false,
    setAuth: (user) => {
        set({ user, isAuthenticated: true });
    },
    updateUser: (user) => set({ user }),
    logout: async () => {
        try {
            await apiClient.post('/logout');
        } catch (error) {
            console.error('Logout failed:', error);
        } finally {
            set({ user: null, isAuthenticated: false });
            if (typeof window !== 'undefined') {
                window.location.href = '/login';
            }
        }
    },
    isAdmin: () => {
        const { user } = get();
        return user?.roles?.some(role => role.name === 'admin') ?? false;
    },
}));
