<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdminLog extends Model
{
    protected $fillable = [
        'admin_id', 'action', 'entity_type', 'entity_id', 
        'description', 'ip_address', 'metadata'
    ];

    protected $casts = [
        'metadata' => 'json',
    ];

    public function admin()
    {
        return $this->belongsTo(User::class, 'admin_id');
    }
}
