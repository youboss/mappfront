<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WalletRequest extends Model
{
    protected $fillable = [
        'user_id', 'amount', 'payment_proof_url', 'status', 
        'admin_notes', 'approved_by', 'approved_at', 'rejected_at'
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'approved_at' => 'datetime',
        'rejected_at' => 'datetime',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function approver()
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function transactions()
    {
        return $this->morphMany(WalletTransaction::class, 'reference');
    }
}
