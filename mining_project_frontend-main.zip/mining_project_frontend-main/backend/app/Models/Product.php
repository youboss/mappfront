<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'name', 'slug', 'description', 'short_description', 
        'price', 'image_url', 'images', 'status', 
        'power_consumption', 'efficiency', 'daily_revenue', 'hosting_type',
        'created_by', 'updated_by'
    ];

    protected $casts = [
        'images' => 'json',
        'price' => 'decimal:2',
    ];

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updater()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}
