<?php

namespace App;

trait HasRoles
{
    //
}
