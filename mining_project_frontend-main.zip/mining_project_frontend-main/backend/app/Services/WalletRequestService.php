<?php

namespace App\Services;

use App\Models\WalletRequest;
use App\Models\User;
use App\Models\AdminLog;
use Illuminate\Support\Facades\DB;
use Exception;

class WalletRequestService
{
    public function __construct(
        private WalletService $walletService
    ) {}

    /**
     * Approve wallet request
     */
    public function approve(WalletRequest $request, User $admin): void
    {
        if ($request->status !== 'pending') {
            throw new Exception('Only pending requests can be approved');
        }

        DB::transaction(function () use ($request, $admin) {
            $request->update([
                'status' => 'approved',
                'approved_by' => $admin->id,
                'approved_at' => now(),
            ]);

            $this->walletService->addCredit(
                user: $request->user,
                amount: $request->amount,
                referenceType: 'wallet_request',
                referenceId: $request->id,
                description: "Wallet request #{$request->id} approved"
            );

            AdminLog::create([
                'admin_id' => $admin->id,
                'action' => 'approve_wallet_request',
                'entity_type' => 'wallet_request',
                'entity_id' => $request->id,
                'description' => "Approved wallet request of {$request->amount} for user #{$request->user_id}",
            ]);
        });
    }

    /**
     * Reject wallet request
     */
    public function reject(WalletRequest $request, User $admin, string $reason = null): void
    {
        if ($request->status !== 'pending') {
            throw new Exception('Only pending requests can be rejected');
        }

        DB::transaction(function () use ($request, $admin, $reason) {
            $request->update([
                'status' => 'rejected',
                'admin_notes' => $reason,
                'rejected_at' => now(),
            ]);

            AdminLog::create([
                'admin_id' => $admin->id,
                'action' => 'reject_wallet_request',
                'entity_type' => 'wallet_request',
                'entity_id' => $request->id,
                'description' => "Rejected wallet request of {$request->amount} for user #{$request->user_id}",
                'metadata' => ['reason' => $reason],
            ]);
        });
    }
}
