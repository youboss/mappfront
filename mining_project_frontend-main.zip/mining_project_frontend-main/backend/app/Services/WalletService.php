<?php

namespace App\Services;

use App\Models\User;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\DB;
use Exception;

class WalletService
{
    /**
     * Get current wallet balance for user
     */
    public function getBalance(User $user): float
    {
        return WalletTransaction::where('user_id', $user->id)
            ->orderBy('id', 'desc')
            ->value('balance_after') ?? 0.00;
    }

    /**
     * Add credit to wallet
     */
    public function addCredit(
        User $user,
        float $amount,
        string $referenceType = null,
        int $referenceId = null,
        string $description = null,
        array $metadata = null
    ): WalletTransaction {
        return DB::transaction(function () use ($user, $amount, $referenceType, $referenceId, $description, $metadata) {
            // Lock user's last transaction for update to prevent race conditions
            $lastTransaction = WalletTransaction::where('user_id', $user->id)
                ->lockForUpdate()
                ->orderBy('id', 'desc')
                ->first();

            $currentBalance = $lastTransaction ? $lastTransaction->balance_after : 0.00;
            $newBalance = $currentBalance + $amount;

            return WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'CREDIT',
                'amount' => $amount,
                'balance_after' => $newBalance,
                'reference_type' => $referenceType,
                'reference_id' => $referenceId,
                'description' => $description ?? 'Wallet credited',
                'metadata' => $metadata,
            ]);
        });
    }

    /**
     * Deduct from wallet
     */
    public function deductBalance(
        User $user,
        float $amount,
        string $referenceType = null,
        int $referenceId = null,
        string $description = null,
        array $metadata = null
    ): WalletTransaction {
        return DB::transaction(function () use ($user, $amount, $referenceType, $referenceId, $description, $metadata) {
            // Lock user's last transaction for update
            $lastTransaction = WalletTransaction::where('user_id', $user->id)
                ->lockForUpdate()
                ->orderBy('id', 'desc')
                ->first();

            $currentBalance = $lastTransaction ? $lastTransaction->balance_after : 0.00;

            if ($currentBalance < $amount) {
                throw new Exception('Insufficient wallet balance');
            }

            $newBalance = $currentBalance - $amount;

            return WalletTransaction::create([
                'user_id' => $user->id,
                'type' => 'DEBIT',
                'amount' => $amount,
                'balance_after' => $newBalance,
                'reference_type' => $referenceType,
                'reference_id' => $referenceId,
                'description' => $description ?? 'Wallet debited',
                'metadata' => $metadata,
            ]);
        });
    }

    /**
     * Get transaction history
     */
    public function getTransactionHistory(User $user, int $perPage = 15)
    {
        return WalletTransaction::where('user_id', $user->id)
            ->orderBy('id', 'desc')
            ->paginate($perPage);
    }
}
