<?php

namespace App\Services;

use App\Models\User;
use App\Models\Product;
use App\Models\Purchase;
use Illuminate\Support\Facades\DB;
use Exception;

class PurchaseService
{
    public function __construct(
        private WalletService $walletService
    ) {}

    /**
     * Process product purchase
     */
    public function processPurchase(User $user, Product $product, int $quantity = 1): Purchase
    {
        if ($product->status !== 'active') {
            throw new Exception('Product is not available for purchase');
        }

        $totalAmount = $product->price * $quantity;

        return DB::transaction(function () use ($user, $product, $quantity, $totalAmount) {
            // Deduct from wallet first (includes balance check and row locking)
            $walletTransaction = $this->walletService->deductBalance(
                user: $user,
                amount: $totalAmount,
                referenceType: 'purchase',
                description: "Purchase: {$product->name} (x{$quantity})"
            );

            // Create purchase record
            $purchase = Purchase::create([
                'user_id' => $user->id,
                'product_id' => $product->id,
                'quantity' => $quantity,
                'price' => $product->price,
                'total_amount' => $totalAmount,
                'wallet_transaction_id' => $walletTransaction->id,
                'status' => 'completed',
            ]);

            // Update wallet transaction with purchase ID reference
            $walletTransaction->update([
                'reference_id' => $purchase->id,
            ]);

            return $purchase;
        });
    }
}
