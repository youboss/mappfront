<?php

namespace App\Traits;

use App\Models\Role;

trait HasRoles
{
    public function roles()
    {
        return $this->belongsToMany(Role::class);
    }

    public function hasRole(string $role): bool
    {
        return $this->roles()->where('name', $role)->exists();
    }

    public function isAdmin(): bool
    {
        return $this->hasRole('admin');
    }

    public function assignRole(string $role)
    {
        $roleRecord = Role::where('name', $role)->first();
        if ($roleRecord) {
            $this->roles()->syncWithoutDetaching([$roleRecord->id]);
        }
    }
}
