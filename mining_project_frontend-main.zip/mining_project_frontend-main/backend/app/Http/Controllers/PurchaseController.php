<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Services\PurchaseService;
use App\Models\Product;
use App\Models\Purchase;

class PurchaseController extends Controller
{
    public function __construct(
        private PurchaseService $purchaseService
    ) {}

    public function buy(Request $request)
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
        ]);

        $product = Product::findOrFail($request->product_id);

        try {
            $purchase = $this->purchaseService->processPurchase(
                $request->user(),
                $product,
                $request->quantity
            );

            return response()->json([
                'success' => true,
                'message' => 'Purchase successful',
                'data' => $purchase,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function index(Request $request)
    {
        $purchases = Purchase::with('product')
            ->where('user_id', $request->user()->id)
            ->orderBy('created_at', 'desc')
            ->paginate(15);

        return response()->json([
            'success' => true,
            'data' => $purchases,
        ]);
    }

    public function show(Request $request, $id)
    {
        $purchase = Purchase::with('product', 'walletTransaction')
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        return response()->json([
            'success' => true,
            'data' => $purchase,
        ]);
    }
}
