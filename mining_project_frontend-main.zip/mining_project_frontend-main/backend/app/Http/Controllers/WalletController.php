<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Services\WalletService;
use App\Models\WalletRequest;

class WalletController extends Controller
{
    public function __construct(
        private WalletService $walletService
    ) {}

    public function balance(Request $request)
    {
        return response()->json([
            'success' => true,
            'data' => [
                'balance' => $this->walletService->getBalance($request->user()),
            ],
        ]);
    }

    public function transactions(Request $request)
    {
        return response()->json([
            'success' => true,
            'data' => $this->walletService->getTransactionHistory($request->user()),
        ]);
    }

    public function requestAddFunds(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:1',
            'payment_proof' => 'required|file|image|max:2048', // 2MB max
        ]);

        $path = $request->file('payment_proof')->store('payment-proofs', 'public');

        $walletRequest = WalletRequest::create([
            'user_id' => $request->user()->id,
            'amount' => $request->amount,
            'payment_proof_url' => $path,
            'status' => 'pending',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Wallet fund request submitted successfully',
            'data' => $walletRequest,
        ], 201);
    }
    
    public function requests(Request $request)
    {
        $requests = WalletRequest::where('user_id', $request->user()->id)
            ->orderBy('created_at', 'desc')
            ->paginate(15);

        return response()->json([
            'success' => true,
            'data' => $requests,
        ]);
    }
}
