<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Product;
use App\Models\WalletRequest;
use App\Models\Purchase;

class DashboardController extends Controller
{
    public function stats()
    {
        return response()->json([
            'success' => true,
            'data' => [
                'total_users' => User::count(),
                'total_products' => Product::count(),
                'pending_wallet_requests' => WalletRequest::where('status', 'pending')->count(),
                'total_purchases' => Purchase::count(),
                'total_revenue' => Purchase::sum('total_amount'),
            ],
        ]);
    }
}
