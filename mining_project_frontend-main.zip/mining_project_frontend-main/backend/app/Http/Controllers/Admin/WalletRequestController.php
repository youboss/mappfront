<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\WalletRequest;
use App\Services\WalletRequestService;

class WalletRequestController extends Controller
{
    public function __construct(
        private WalletRequestService $walletRequestService
    ) {}

    public function index(Request $request)
    {
        $status = $request->query('status', 'pending');
        $requests = WalletRequest::with('user')
            ->when($status, function ($query, $status) {
                return $query->where('status', $status);
            })
            ->orderBy('created_at', 'desc')
            ->paginate(15);

        return response()->json([
            'success' => true,
            'data' => $requests,
        ]);
    }

    public function approve(Request $request, $id)
    {
        $walletRequest = WalletRequest::findOrFail($id);

        try {
            $this->walletRequestService->approve($walletRequest, $request->user());

            return response()->json([
                'success' => true,
                'message' => 'Wallet request approved successfully',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }

    public function reject(Request $request, $id)
    {
        $request->validate([
            'reason' => 'nullable|string|max:255',
        ]);

        $walletRequest = WalletRequest::findOrFail($id);

        try {
            $this->walletRequestService->reject($walletRequest, $request->user(), $request->reason);

            return response()->json([
                'success' => true,
                'message' => 'Wallet request rejected successfully',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        }
    }
}
