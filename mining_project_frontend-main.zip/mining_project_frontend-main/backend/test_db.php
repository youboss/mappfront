<?php
$dsn = "pgsql:host=127.0.0.1;port=5432;dbname=postgres";
$users = ['postgres', 'root', 'trumatics'];
$passwords = ['postgres', 'password', 'root', 'admin', '123456', ''];

foreach ($users as $user) {
    foreach ($passwords as $pass) {
        try {
            $pdo = new PDO($dsn, $user, $pass);
            echo "SUCCESS: User: $user, Pass: $pass\n";
            exit(0);
        } catch (PDOException $e) {
            // echo "Failed: $user / $pass - " . $e->getMessage() . "\n";
        }
    }
}
echo "FAILURE: Could not connect with common credentials.\n";
