<?php
$envContent = file_get_contents('.env.example');
$envContent = str_replace('DB_CONNECTION=sqlite', 'DB_CONNECTION=pgsql', $envContent);
$envContent = str_replace('# DB_HOST=127.0.0.1', 'DB_HOST=127.0.0.1', $envContent);
$envContent = str_replace('# DB_PORT=3306', 'DB_PORT=5432', $envContent);
$envContent = str_replace('# DB_DATABASE=laravel', 'DB_DATABASE=mining_app', $envContent);
$envContent = str_replace('# DB_USERNAME=root', 'DB_USERNAME=postgres', $envContent);
$envContent = str_replace('# DB_PASSWORD=', 'DB_PASSWORD=password', $envContent);
$envContent = str_replace('APP_KEY=', 'APP_KEY=' . trim(file_get_contents('key.txt')), $envContent); // We need the key

// Also fix the key since I'm rewriting from example
// I'll just grab the key from current .env via regex if I can, or regenerate it
// Simpler: Just run key:generate again after replacing.

file_put_contents('.env', $envContent);
echo ".env written.\n";
