<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);

$kernel->bootstrap();

use App\Models\User;
use App\Models\WalletTransaction;

$users = User::all();

echo "Funding users...\n";

foreach ($users as $user) {
    echo "Processing User: {$user->email} (ID: {$user->id})\n";

    // Get last transaction to calculate balance
    $lastTransaction = WalletTransaction::where('user_id', $user->id)
        ->orderBy('id', 'desc')
        ->first();

    $currentBalance = $lastTransaction ? $lastTransaction->balance_after : 0.00;

    echo "  Current Balance: $" . $currentBalance . "\n";

    if ($currentBalance < 10000) {
        $amount = 50000.00;
        $newBalance = $currentBalance + $amount;

        WalletTransaction::create([
            'user_id' => $user->id,
            'type' => 'CREDIT',
            'amount' => $amount,
            'balance_after' => $newBalance,
            'reference_type' => 'system_gift', // internal reference
            'description' => 'System Test Funds',
            'metadata' => ['reason' => 'testing'],
        ]);

        echo "  Added $" . $amount . ". New Balance: $" . $newBalance . "\n";
    } else {
        echo "  Balance sufficient. Skipping.\n";
    }
}

echo "Done.\n";
