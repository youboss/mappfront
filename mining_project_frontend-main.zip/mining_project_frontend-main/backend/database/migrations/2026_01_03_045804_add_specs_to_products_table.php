<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('power_consumption')->nullable()->after('price'); // e.g., "3010 W"
            $table->string('efficiency')->nullable()->after('power_consumption'); // e.g., "21.5 J/TH"
            $table->string('daily_revenue')->nullable()->after('efficiency'); // e.g., "0.00045 BTC"
            $table->string('hosting_type')->nullable()->after('daily_revenue'); // e.g., "Included"
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn(['power_consumption', 'efficiency', 'daily_revenue', 'hosting_type']);
        });
    }
};
