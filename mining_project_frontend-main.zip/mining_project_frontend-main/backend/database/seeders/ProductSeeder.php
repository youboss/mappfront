<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Str;

class ProductSeeder extends Seeder
{
    public function run()
    {
        // Get the first admin user or just the first user to assign as creator
        $admin = User::whereHas('roles', function($q) {
            $q->where('name', 'admin');
        })->first();

        // If no admin exists, we can't properly assign created_by, but maybe nullable?
        // Let's assume DatabaseSeeder runs first and creates admin.
        $creatorId = $admin ? $admin->id : 1;

        $products = [
            [
                'name' => 'Antminer S19 XP',
                'description' => 'The Antminer S19 XP is Bitmain\'s latest air-cooled miner based on a 5nm chip design. It offers industry-leading power efficiency and reliability.',
                'short_description' => '140 TH/s Hashrate',
                'price' => 4500.00,
                'power_consumption' => '3010 W',
                'efficiency' => '21.5 J/TH',
                'daily_revenue' => '0.00045 BTC',
                'hosting_type' => 'Included',
                'image_url' => null,
                'status' => 'active',
            ],
            [
                'name' => 'WhatsMiner M50S',
                'description' => 'WhatsMiner M50S is a high-performance ASIC miner with excellent stability and efficiency for prolonged mining operations.',
                'short_description' => '126 TH/s Hashrate',
                'price' => 3200.00,
                'power_consumption' => '3276 W', // Estimated based on efficiency
                'efficiency' => '26 J/TH',
                'daily_revenue' => '0.00038 BTC',
                'hosting_type' => 'Included',
                'image_url' => null,
                'status' => 'active',
            ],
            [
                'name' => 'Starter Cloud Plan',
                'description' => 'Perfect for beginners, the Starter Cloud Plan offers a hassle-free entry into crypto mining with no hardware maintenance.',
                'short_description' => '10 TH/s Cloud Mining',
                'price' => 250.00,
                'power_consumption' => 'N/A',
                'efficiency' => 'Cloud',
                'daily_revenue' => '0.00003 BTC',
                'hosting_type' => 'Included',
                'image_url' => null,
                'status' => 'active',
            ],
            [
                'name' => 'Pro Cloud 50',
                'description' => 'Maximize your returns with the Pro Cloud 50 plan, offering significant hashrate without the noise or heat of home mining.',
                'short_description' => '50 TH/s Cloud Mining',
                'price' => 1100.00,
                'power_consumption' => 'N/A',
                'efficiency' => 'Cloud',
                'daily_revenue' => '0.00015 BTC',
                'hosting_type' => 'Included',
                'image_url' => null,
                'status' => 'active',
            ],
        ];

        foreach ($products as $product) {
            Product::updateOrCreate(
                ['name' => $product['name']], // Check by name to avoid duplicates
                [
                    'slug' => Str::slug($product['name']),
                    'description' => $product['description'],
                    'short_description' => $product['short_description'],
                    'price' => $product['price'],
                    'power_consumption' => $product['power_consumption'],
                    'efficiency' => $product['efficiency'],
                    'daily_revenue' => $product['daily_revenue'],
                    'hosting_type' => $product['hosting_type'],
                    'image_url' => $product['image_url'],
                    'status' => $product['status'],
                    'created_by' => $creatorId,
                ]
            );
        }
    }
}
