<?php
try {
    $pdo = new PDO("pgsql:host=127.0.0.1;port=5432;dbname=postgres", "postgres", "password");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $stmt = $pdo->query("SELECT 1 FROM pg_database WHERE datname = 'mining_app'");
    $exists = $stmt->fetchColumn();

    if (!$exists) {
        $pdo->exec("CREATE DATABASE mining_app");
        echo "Database 'mining_app' created successfully.\n";
    } else {
        echo "Database 'mining_app' already exists.\n";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
