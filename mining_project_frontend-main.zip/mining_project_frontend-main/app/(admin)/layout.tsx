"use client";

import { AdminSidebar } from "@/components/admin/AdminSidebar";
import { useAuthStore } from "@/store/authStore";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";

export default function AdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const { user, isAuthenticated, isAdmin } = useAuthStore();
    const router = useRouter();
    const [authorized, setAuthorized] = useState(false);

    useEffect(() => {
        if (!isAuthenticated) {
            router.push("/login"); // Need to authenticate first
            return;
        }

        if (!isAdmin()) {
            // For security, we redirect to a non-existent path to obscure the admin panel
            router.push("/not-found");
            return;
        }

        setAuthorized(true);
    }, [isAuthenticated, isAdmin, router]);

    if (!authorized) {
        return (
            <div className="h-screen w-full flex items-center justify-center bg-black text-white">
                <Loader2 className="w-8 h-8 animate-spin text-zinc-500" />
            </div>
        );
    }

    return (
        <div className="flex min-h-screen bg-[#0a0a0a] relative overflow-hidden">
            {/* Premium Background Elements */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px]" />
            <div className="absolute top-0 left-0 right-0 h-[500px] bg-gradient-to-b from-red-500/5 via-violet-500/2 to-transparent blur-[120px] pointer-events-none" />

            <div className="hidden lg:block w-64 fixed inset-y-0 z-50">
                <AdminSidebar />
            </div>

            <div className="lg:pl-64 flex-1 flex flex-col min-h-screen relative z-10">
                <main className="flex-1 p-6 lg:p-10">
                    {children}
                </main>
            </div>
        </div>
    );
}
