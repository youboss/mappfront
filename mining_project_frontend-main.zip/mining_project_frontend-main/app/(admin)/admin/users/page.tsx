"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { MoreHorizontal, Loader2, Power, Eye, User as UserIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";
import apiClient from "@/lib/api";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { UserDetailDialog } from "@/components/admin/UserDetailDialog";
import { toast } from "sonner";

interface User {
    id: number;
    name: string;
    email: string;
    status: string;
    created_at: string;
    roles: { name: string }[];
}

export default function AdminUsersPage() {
    const [users, setUsers] = useState<User[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
    const [dialogOpen, setDialogOpen] = useState(false);

    const fetchUsers = async () => {
        setLoading(true);
        try {
            const response = await apiClient.get('/admin/users');
            if (response.data.success) {
                setUsers(response.data.data.data);
            }
        } catch (error) {
            console.error("Failed to fetch users:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsers();
    }, []);

    const handleToggleStatus = async (id: number) => {
        try {
            await apiClient.post(`/admin/users/${id}/toggle-status`);
            // Optimistic update or refresh
            setUsers(users.map(u => u.id === id ? { ...u, status: u.status === 'active' ? 'inactive' : 'active' } : u));
            toast.success("User status updated successfully");
        } catch (error: any) {
            console.error("Failed to toggle status:", error);
            const message = error.response?.data?.message || "Failed to update user status";
            toast.error(message);
        }
    };

    const handleViewDetails = (id: number) => {
        setSelectedUserId(id);
        setDialogOpen(true);
    };

    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white tracking-tight">User Management</h1>
                    <p className="text-zinc-400 mt-1">Monitor and manage platform user accounts and permissions.</p>
                </div>
            </div>

            <Card className="glass-card border-white/5 bg-zinc-950/40 backdrop-blur-sm overflow-hidden">
                <CardContent className="p-0">
                    {loading ? (
                        <div className="flex justify-center items-center py-20">
                            <Loader2 className="animate-spin text-zinc-500" />
                        </div>
                    ) : (
                        <Table>
                            <TableHeader className="bg-white/5">
                                <TableRow className="border-white/5 hover:bg-transparent">
                                    <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Account Profile</TableHead>
                                    <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Security Role</TableHead>
                                    <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Current Status</TableHead>
                                    <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Registration</TableHead>
                                    <TableHead className="text-right text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4 px-6">Operations</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {users.map((user) => (
                                    <TableRow key={user.id} className="border-white/5 hover:bg-white/5 transition-colors group text-sm">
                                        <TableCell className="py-4">
                                            <div className="flex items-center gap-4">
                                                <div className="w-10 h-10 rounded-full bg-zinc-900 border border-white/10 flex items-center justify-center uppercase text-xs font-bold text-zinc-400 flex-shrink-0 group-hover:border-red-500/30 transition-colors">
                                                    {user.name[0]}
                                                </div>
                                                <div className="flex flex-col">
                                                    <span className="font-bold text-white group-hover:text-red-400 transition-colors">{user.name}</span>
                                                    <span className="text-xs text-zinc-500">{user.email}</span>
                                                </div>
                                            </div>
                                        </TableCell>
                                        <TableCell className="py-4">
                                            <span className={cn(
                                                "text-[10px] font-bold px-2.5 py-1 rounded-full border uppercase tracking-wider",
                                                user.roles[0]?.name === 'admin'
                                                    ? "bg-red-500/10 text-red-500 border-red-500/20"
                                                    : "bg-blue-500/10 text-blue-400 border-blue-500/20"
                                            )}>
                                                {user.roles[0]?.name || 'User'}
                                            </span>
                                        </TableCell>
                                        <TableCell className="py-4">
                                            <span className={cn(
                                                "text-[10px] font-bold px-2.5 py-1 rounded-full border uppercase tracking-wider",
                                                user.status === 'active'
                                                    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                                                    : "bg-zinc-500/10 text-zinc-400 border-zinc-500/20"
                                            )}>
                                                {user.status}
                                            </span>
                                        </TableCell>
                                        <TableCell className="py-4 text-zinc-400 whitespace-nowrap">
                                            {new Date(user.created_at).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                                        </TableCell>
                                        <TableCell className="text-right py-4 px-6">
                                            <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                    <Button variant="ghost" size="icon" className="h-9 w-9 rounded-xl text-zinc-400 hover:text-white hover:bg-white/10 border border-transparent hover:border-white/10 transition-all">
                                                        <MoreHorizontal className="w-4 h-4" />
                                                    </Button>
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent align="end" className="bg-zinc-950/95 backdrop-blur-xl border border-white/10 text-white min-w-[160px] p-2 rounded-2xl">
                                                    <DropdownMenuLabel className="px-3 py-2 text-[10px] font-bold text-zinc-500 uppercase tracking-widest">User Options</DropdownMenuLabel>
                                                    <DropdownMenuSeparator className="bg-white/5 mx-1" />
                                                    <DropdownMenuItem onClick={() => handleViewDetails(user.id)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-white/5 focus:bg-white/5 transition-colors">
                                                        <Eye className="w-4 h-4 text-zinc-400" />
                                                        <span className="text-sm font-medium">Detailed Profile</span>
                                                    </DropdownMenuItem>
                                                    <DropdownMenuItem onClick={() => handleToggleStatus(user.id)} className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-red-500/10 focus:bg-red-500/10 transition-colors group/item">
                                                        <Power className="w-4 h-4 text-amber-500 group-hover/item:text-red-500" />
                                                        <span className="text-sm font-medium group-hover/item:text-red-400">
                                                            {user.status === 'active' ? 'Deactivate User' : 'Activate User'}
                                                        </span>
                                                    </DropdownMenuItem>
                                                </DropdownMenuContent>
                                            </DropdownMenu>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    )}
                </CardContent>
            </Card>

            <UserDetailDialog
                userId={selectedUserId}
                open={dialogOpen}
                onOpenChange={setDialogOpen}
            />
        </div>
    );
}
