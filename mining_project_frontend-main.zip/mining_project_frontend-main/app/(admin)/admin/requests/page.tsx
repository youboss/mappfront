"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Check, X, Eye, Loader2, Wallet } from "lucide-react";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";
import apiClient from "@/lib/api";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";

interface WalletRequest {
    id: string;
    user: { name: string; email: string };
    amount: string;
    type: string;
    status: string;
    created_at: string;
    payment_proof_url?: string;
    withdrawal_address?: string;
}

export default function AdminRequestsPage() {
    const [requests, setRequests] = useState<WalletRequest[]>([]);
    const [loading, setLoading] = useState(true);
    const [status, setStatus] = useState("pending");

    const fetchRequests = async () => {
        setLoading(true);
        try {
            const response = await apiClient.get(`/admin/wallet-requests?status=${status}`);
            if (response.data.success) {
                setRequests(response.data.data.data);
            }
        } catch (error) {
            console.error("Failed to fetch requests:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchRequests();
    }, [status]); // Refetch when status changes

    const handleApprove = async (id: string) => {
        if (!confirm("Are you sure you want to approve this request?")) return;
        try {
            await apiClient.post(`/admin/wallet-requests/${id}/approve`);
            toast.success('Request approved successfully');
            fetchRequests();
        } catch (error) {
            console.error("Failed to approve request:", error);
            toast.error("Failed to approve request");
        }
    };

    const handleReject = async (id: string) => {
        const reason = prompt("Enter reason for rejection:");
        if (reason === null) return; // Cancelled

        try {
            await apiClient.post(`/admin/wallet-requests/${id}/reject`, { reason });
            toast.success('Request rejected successfully');
            fetchRequests();
        } catch (error) {
            console.error("Failed to reject request:", error);
            toast.error("Failed to reject request");
        }
    };

    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white tracking-tight">Wallet Requests</h1>
                    <p className="text-zinc-400 mt-1">Audit and process financial transactions across the platform.</p>
                </div>
            </div>

            <div className="flex flex-col gap-6">
                <Tabs value={status} onValueChange={setStatus} className="w-full">
                    <TabsList className="bg-zinc-950/50 border border-white/5 p-1 rounded-xl h-12">
                        <TabsTrigger value="pending" className="rounded-lg px-6 data-[state=active]:bg-red-500 data-[state=active]:text-white transition-all">Pending</TabsTrigger>
                        <TabsTrigger value="approved" className="rounded-lg px-6 data-[state=active]:bg-emerald-500 data-[state=active]:text-white transition-all">Approved</TabsTrigger>
                        <TabsTrigger value="rejected" className="rounded-lg px-6 data-[state=active]:bg-zinc-700 data-[state=active]:text-white transition-all">Rejected</TabsTrigger>
                    </TabsList>
                </Tabs>

                <Card className="glass-card border-white/5 bg-zinc-950/40 backdrop-blur-sm overflow-hidden">
                    <CardContent className="p-0">
                        {loading ? (
                            <div className="flex justify-center items-center py-20">
                                <Loader2 className="animate-spin text-zinc-500" />
                            </div>
                        ) : (
                            <Table>
                                <TableHeader className="bg-white/5">
                                    <TableRow className="border-white/5 hover:bg-transparent">
                                        <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Requester</TableHead>
                                        <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Transaction Details</TableHead>
                                        <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Amount</TableHead>
                                        <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Timestamp</TableHead>
                                        <TableHead className="text-right text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4 px-6">Operations</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {requests.length === 0 ? (
                                        <TableRow>
                                            <TableCell colSpan={5} className="text-center py-10 text-zinc-500">
                                                No {status} requests found.
                                            </TableCell>
                                        </TableRow>
                                    ) : (
                                        requests.map((req) => (
                                            <TableRow key={req.id} className="border-white/5 hover:bg-white/5 transition-colors group text-sm">
                                                <TableCell className="py-4">
                                                    <div className="flex items-center gap-4">
                                                        <div className="w-10 h-10 rounded-full bg-zinc-900 border border-white/10 flex items-center justify-center text-xs font-bold text-zinc-500 flex-shrink-0">
                                                            {req.user?.name[0]}
                                                        </div>
                                                        <div className="flex flex-col">
                                                            <span className="font-bold text-white group-hover:text-red-400 transition-colors">{req.user?.name}</span>
                                                            <span className="text-xs text-zinc-500">{req.user?.email}</span>
                                                        </div>
                                                    </div>
                                                </TableCell>
                                                <TableCell className="py-4">
                                                    <div className="flex flex-col gap-1.5">
                                                        <span className={cn(
                                                            "inline-flex w-fit items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border",
                                                            req.type === 'deposit'
                                                                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                                                                : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                                                        )}>
                                                            {req.type}
                                                        </span>
                                                        {req.type === 'withdrawal' && req.withdrawal_address && (
                                                            <div className="flex items-center gap-1 text-[10px] text-zinc-500 font-mono bg-white/5 px-2 py-0.5 rounded-md border border-white/5">
                                                                <Wallet className="w-3 h-3" />
                                                                <span className="truncate max-w-[120px]" title={req.withdrawal_address}>{req.withdrawal_address}</span>
                                                            </div>
                                                        )}
                                                    </div>
                                                </TableCell>
                                                <TableCell className="py-4">
                                                    <span className="text-sm font-bold text-white tracking-tight">${Number(req.amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                                                </TableCell>
                                                <TableCell className="py-4 text-zinc-500 text-xs whitespace-nowrap">
                                                    {new Date(req.created_at).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}
                                                </TableCell>
                                                <TableCell className="text-right py-4 px-6">
                                                    <div className="flex justify-end gap-2">
                                                        {req.payment_proof_url && (
                                                            <Button variant="ghost" size="icon" className="h-9 w-9 rounded-xl text-blue-400 hover:text-white hover:bg-blue-500/10 border border-transparent hover:border-blue-500/10 transition-all" onClick={() => window.open(`http://localhost:8000/storage/${req.payment_proof_url}`, '_blank')} title="View Proof">
                                                                <Eye className="w-4 h-4" />
                                                            </Button>
                                                        )}
                                                        {status === 'pending' && (
                                                            <>
                                                                <Button onClick={() => handleApprove(req.id)} variant="ghost" size="icon" className="h-9 w-9 rounded-xl text-emerald-400 hover:text-white hover:bg-emerald-500/10 border border-transparent hover:border-emerald-500/10 transition-all" title="Approve">
                                                                    <Check className="w-4 h-4" />
                                                                </Button>
                                                                <Button onClick={() => handleReject(req.id)} variant="ghost" size="icon" className="h-9 w-9 rounded-xl text-red-400/70 hover:text-white hover:bg-red-500/10 border border-transparent hover:border-red-500/10 transition-all" title="Reject">
                                                                    <X className="w-4 h-4" />
                                                                </Button>
                                                            </>
                                                        )}
                                                    </div>
                                                </TableCell>
                                            </TableRow>
                                        ))
                                    )}
                                </TableBody>
                            </Table>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
