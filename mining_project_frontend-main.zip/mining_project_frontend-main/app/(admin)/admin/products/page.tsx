"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Plus, Pencil, Trash, Loader2, Package } from "lucide-react";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";
import apiClient from "@/lib/api";
import { ProductDialog } from "@/components/admin/ProductDialog";

interface Product {
    id: number;
    name: string;
    description: string | null;
    price: number;
    stock: number; // Note: specific stock management not in simple update yet, might need adjustment
    status: string;
    image_url: string | null;
}

export default function AdminProductsPage() {
    const [products, setProducts] = useState<Product[]>([]);
    const [loading, setLoading] = useState(true);
    const [dialogOpen, setDialogOpen] = useState(false);
    const [editingProduct, setEditingProduct] = useState<Product | null>(null);

    const fetchProducts = async () => {
        setLoading(true);
        try {
            const response = await apiClient.get('/admin/products');
            if (response.data.success) {
                // Determine if data is paginated or not. Controller returns paginate(15)
                setProducts(response.data.data.data);
            }
        } catch (error) {
            console.error("Failed to fetch products:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchProducts();
    }, []);

    const handleEdit = (product: Product) => {
        setEditingProduct(product);
        setDialogOpen(true);
    };

    const handleAddNew = () => {
        setEditingProduct(null);
        setDialogOpen(true);
    };

    const handleDelete = async (id: number) => {
        if (!confirm("Are you sure you want to delete this product?")) return;

        try {
            await apiClient.delete(`/admin/products/${id}`);
            fetchProducts(); // Refresh list
        } catch (error) {
            console.error("Failed to delete product:", error);
        }
    };

    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white tracking-tight">Product Management</h1>
                    <p className="text-zinc-400 mt-1">Configure and manage mining contracts and hardware.</p>
                </div>
                <Button onClick={handleAddNew} className="bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-900/20 border-none px-6">
                    <Plus className="w-4 h-4 mr-2" /> Create New Product
                </Button>
            </div>

            <Card className="glass-card border-white/5 bg-zinc-950/40 backdrop-blur-sm overflow-hidden">
                <CardContent className="p-0">
                    {loading ? (
                        <div className="flex justify-center items-center py-20">
                            <Loader2 className="animate-spin text-zinc-500" />
                        </div>
                    ) : (
                        <Table>
                            <TableHeader className="bg-white/5">
                                <TableRow className="border-white/5 hover:bg-transparent">
                                    <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Product Info</TableHead>
                                    <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Unit Price</TableHead>
                                    <TableHead className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4">Status</TableHead>
                                    <TableHead className="text-right text-[10px] font-bold text-zinc-500 uppercase tracking-widest py-4 px-6">Operations</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {products.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={4} className="text-center py-10 text-zinc-500">
                                            No products found.
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    products.map((product) => (
                                        <TableRow key={product.id} className="border-white/5 hover:bg-white/5 transition-colors group">
                                            <TableCell className="py-4">
                                                <div className="flex items-center gap-4">
                                                    <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-white/5 overflow-hidden flex-shrink-0">
                                                        {product.image_url ? (
                                                            <img src={`http://localhost:8000/storage/${product.image_url}`} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                                        ) : (
                                                            <div className="w-full h-full flex items-center justify-center text-zinc-700">
                                                                <Package className="w-6 h-6" />
                                                            </div>
                                                        )}
                                                    </div>
                                                    <div className="flex flex-col">
                                                        <span className="font-bold text-white group-hover:text-emerald-400 transition-colors">{product.name}</span>
                                                        <span className="text-xs text-zinc-500 mt-0.5">ID: PROD-{product.id}</span>
                                                    </div>
                                                </div>
                                            </TableCell>
                                            <TableCell className="py-4">
                                                <span className="text-sm font-bold text-white">${Number(product.price).toLocaleString()}</span>
                                            </TableCell>
                                            <TableCell className="py-4">
                                                <span className={cn(
                                                    "text-[10px] font-bold px-2.5 py-1 rounded-full border uppercase tracking-wider",
                                                    product.status === 'active' || !product.status
                                                        ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                                                        : "bg-red-500/10 text-red-400 border-red-500/20"
                                                )}>
                                                    {product.status || 'Active'}
                                                </span>
                                            </TableCell>
                                            <TableCell className="text-right py-4 px-6">
                                                <div className="flex justify-end gap-2">
                                                    <Button onClick={() => handleEdit(product)} variant="ghost" size="icon" className="h-9 w-9 rounded-xl text-zinc-400 hover:text-white hover:bg-white/10 border border-transparent hover:border-white/10 transition-all">
                                                        <Pencil className="w-4 h-4" />
                                                    </Button>
                                                    <Button onClick={() => handleDelete(product.id)} variant="ghost" size="icon" className="h-9 w-9 rounded-xl text-red-400/70 hover:text-red-400 hover:bg-red-500/10 border border-transparent hover:border-red-500/10 transition-all">
                                                        <Trash className="w-4 h-4" />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    )}
                </CardContent>
            </Card>

            <ProductDialog
                open={dialogOpen}
                onOpenChange={setDialogOpen}
                productToEdit={editingProduct}
                onProductSaved={fetchProducts}
            />
        </div>
    );
}
