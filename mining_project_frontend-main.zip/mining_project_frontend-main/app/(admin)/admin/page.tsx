"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, DollarSign, Package, AlertTriangle, Loader2, ShieldAlert, Activity, TrendingUp } from "lucide-react";
import { useEffect, useState } from "react";
import apiClient from "@/lib/api";

export default function AdminDashboard() {
    const [stats, setStats] = useState({
        total_users: 0,
        total_products: 0,
        pending_wallet_requests: 0,
        total_purchases: 0,
        total_revenue: 0,
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const response = await apiClient.get('/admin/dashboard/stats');
                if (response.data.success) {
                    setStats(response.data.data);
                }
            } catch (error) {
                console.error("Failed to fetch admin stats:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchStats();
    }, []);

    if (loading) {
        return (
            <div className="flex flex-col h-[60vh] w-full items-center justify-center gap-4">
                <div className="relative">
                    <div className="w-12 h-12 rounded-full border-2 border-red-500/20 border-t-red-500 animate-spin" />
                    <ShieldAlert className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-5 h-5 text-red-500/50" />
                </div>
                <p className="text-zinc-500 text-sm font-medium animate-pulse tracking-widest uppercase">Initializing Secure Dashboard...</p>
            </div>
        );
    }

    return (
        <div className="space-y-10">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white tracking-tight">System Overview</h1>
                    <p className="text-zinc-400 mt-1">Comprehensive analytics and platform control center.</p>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20">
                    <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Live System Data</span>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                <AdminStatCard
                    title="Total Users"
                    value={stats.total_users.toLocaleString()}
                    icon={<Users className="w-5 h-5" />}
                    color="blue"
                    trend="+12%"
                />
                <AdminStatCard
                    title="Platform Revenue"
                    value={`$${Number(stats.total_revenue).toLocaleString()}`}
                    icon={<DollarSign className="w-5 h-5" />}
                    color="emerald"
                    trend="+8%"
                />
                <AdminStatCard
                    title="Active Purchases"
                    value={stats.total_purchases.toLocaleString()}
                    icon={<Package className="w-5 h-5" />}
                    color="violet"
                    trend="+15%"
                />
                <AdminStatCard
                    title="Pending Requests"
                    value={stats.pending_wallet_requests}
                    icon={<AlertTriangle className="w-5 h-5" />}
                    color="amber"
                    description="Requires Attention"
                    isAlert={stats.pending_wallet_requests > 0}
                />
            </div>

            <div className="grid gap-6 md:grid-cols-2">
                <Card className="glass-card border-white/5 bg-zinc-900/20 backdrop-blur-sm overflow-hidden">
                    <CardHeader className="border-b border-white/5 pb-4">
                        <CardTitle className="text-lg font-bold text-white flex items-center gap-2">
                            <Activity className="w-5 h-5 text-red-500" />
                            System Health
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-6">
                        <div className="space-y-6">
                            <HealthItem label="API Status" status="Operational" />
                            <HealthItem label="Database" status="Optimal" />
                            <HealthItem label="Wallet Engine" status="Healthy" />
                            <HealthItem label="Node Performance" status="Excellent" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="glass-card border-white/5 bg-zinc-900/20 backdrop-blur-sm">
                    <CardHeader className="border-b border-white/5 pb-4">
                        <CardTitle className="text-lg font-bold text-white flex items-center gap-2">
                            <TrendingUp className="w-5 h-5 text-violet-500" />
                            Admin Activity
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-6">
                        <div className="flex flex-col items-center justify-center h-[200px] text-center">
                            <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center mb-4">
                                <Activity className="w-6 h-6 text-zinc-600" />
                            </div>
                            <p className="text-zinc-500 text-sm italic">Audit logging is active. All administrative actions are recorded for security.</p>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

function AdminStatCard({ title, value, icon, color, trend, description, isAlert }: any) {
    const colors: any = {
        blue: "text-blue-400 bg-blue-500/10 border-blue-500/20",
        emerald: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
        violet: "text-violet-400 bg-violet-500/10 border-violet-500/20",
        amber: "text-amber-400 bg-amber-500/10 border-amber-500/20",
    };

    return (
        <Card className="glass-card border-white/5 bg-zinc-950/40 hover:bg-zinc-900/40 transition-all duration-300 group overflow-hidden">
            <CardContent className="p-6 relative">
                <div className={`absolute -right-4 -top-4 w-24 h-24 blur-3xl opacity-10 group-hover:opacity-20 transition-opacity bg-${color}-500`} />

                <div className="flex items-center justify-between mb-4">
                    <div className={`p-2.5 rounded-xl border ${colors[color]}`}>
                        {icon}
                    </div>
                    {trend && (
                        <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/10">
                            {trend}
                        </span>
                    )}
                </div>

                <div className="space-y-1">
                    <p className="text-xs font-bold text-zinc-500 uppercase tracking-widest">{title}</p>
                    <div className="flex items-end gap-2">
                        <h3 className="text-3xl font-bold text-white tracking-tight">{value}</h3>
                    </div>
                    {description && (
                        <p className={`text-[10px] font-medium mt-1 ${isAlert ? 'text-amber-500 animate-pulse' : 'text-zinc-500'}`}>
                            {description}
                        </p>
                    )}
                </div>
            </CardContent>
        </Card>
    );
}

function HealthItem({ label, status }: any) {
    return (
        <div className="flex items-center justify-between group">
            <span className="text-sm font-medium text-zinc-400 group-hover:text-white transition-colors">{label}</span>
            <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-400">{status}</span>
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            </div>
        </div>
    );
}
