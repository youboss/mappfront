"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UserPlus, ShoppingCart, Cpu, Wallet, ArrowRight } from "lucide-react";
import Link from "next/link";
import { motion } from "framer-motion";

export default function HowItWorksPage() {
    const steps = [
        {
            id: 1,
            title: "Create Your Account",
            description: "Sign up in seconds. Verify your email to secure your account and access the dashboard.",
            icon: <UserPlus className="w-8 h-8 text-violet-400" />,
            color: "violet"
        },
        {
            id: 2,
            title: "Choose Your Mining Plan",
            description: "Select from our range of high-performance ASICs or flexible cloud mining contracts suited for every budget.",
            icon: <ShoppingCart className="w-8 h-8 text-blue-400" />,
            color: "blue"
        },
        {
            id: 3,
            title: "Start Mining Instantly",
            description: "Once purchased, your hardware is automatically provisioned in our facilities. No setup required.",
            icon: <Cpu className="w-8 h-8 text-emerald-400" />,
            color: "emerald"
        },
        {
            id: 4,
            title: "Receive Daily Payouts",
            description: "Mining rewards are credited to your wallet daily. Withdraw your Bitcoin earnings at any time.",
            icon: <Wallet className="w-8 h-8 text-yellow-400" />,
            color: "yellow"
        }
    ];

    return (
        <div className="container mx-auto px-4 py-20">
            {/* Hero Section */}
            <div className="text-center max-w-3xl mx-auto mb-20 space-y-6">
                <Badge variant="secondary" className="bg-violet-500/10 text-violet-300 border-violet-500/20 backdrop-blur-md px-4 py-1.5 text-sm">
                    Simple Process
                </Badge>
                <h1 className="text-4xl md:text-6xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-500">
                    Start Mining in 4 Easy Steps
                </h1>
                <p className="text-xl text-zinc-400 leading-relaxed">
                    We've simplified the complex world of crypto mining. No hardware to manage, no noise, no heat—just pure mining power.
                </p>
            </div>

            {/* Steps Grid */}
            <div className="grid md:grid-cols-2 gap-6 relative">
                {/* Connecting Line (Desktop) */}
                <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-gradient-to-r from-violet-500/0 via-violet-500/20 to-violet-500/0 -z-10" />

                {steps.map((step, index) => (
                    <motion.div
                        key={step.id}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.1 }}
                    >
                        <Card className="glass-card border-white/5 h-full relative overflow-hidden group hover:border-white/10 transition-all">
                            <div className={`absolute top-0 right-0 p-32 bg-${step.color}-500/5 blur-[100px] rounded-full group-hover:bg-${step.color}-500/10 transition-all duration-500`} />

                            <CardContent className="p-8 space-y-6 relative">
                                <div className="flex justify-between items-start">
                                    <div className={`p-4 rounded-2xl bg-${step.color}-500/10 border border-${step.color}-500/20`}>
                                        {step.icon}
                                    </div>
                                    <span className="text-6xl font-bold text-white/5 group-hover:text-white/10 transition-colors select-none">
                                        0{step.id}
                                    </span>
                                </div>

                                <div>
                                    <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-zinc-400 transition-all">
                                        {step.title}
                                    </h3>
                                    <p className="text-zinc-400 leading-relaxed">
                                        {step.description}
                                    </p>
                                </div>
                            </CardContent>
                        </Card>
                    </motion.div>
                ))}
            </div>

            {/* CTA Section */}
            <div className="mt-20 text-center">
                <Card className="glass-card border-violet-500/20 bg-gradient-to-b from-violet-900/10 to-transparent p-12 relative overflow-hidden">
                    <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-20" />
                    <div className="relative z-10 space-y-8">
                        <h2 className="text-3xl font-bold text-white">Ready to start earning?</h2>
                        <div className="flex flex-col sm:flex-row justify-center gap-4">
                            <Link href="/register">
                                <Button size="lg" className="h-14 px-8 text-lg bg-white text-black hover:bg-zinc-200 w-full sm:w-auto">
                                    Create Account
                                </Button>
                            </Link>
                            <Link href="/products">
                                <Button size="lg" variant="outline" className="h-14 px-8 text-lg border-white/10 text-white hover:bg-white/5 w-full sm:w-auto">
                                    View Products <ArrowRight className="ml-2 w-5 h-5" />
                                </Button>
                            </Link>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    );
}
