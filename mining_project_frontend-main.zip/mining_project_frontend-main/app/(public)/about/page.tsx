"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Globe, Shield, Zap, TrendingUp, Award } from "lucide-react";
import Image from "next/image";

export default function AboutPage() {
    const stats = [
        { label: "Active Miners", value: "15,000+", icon: <Users className="w-5 h-5 text-violet-400" /> },
        { label: "Total Hashrate", value: "850 PH/s", icon: <Zap className="w-5 h-5 text-yellow-400" /> },
        { label: "Countries Served", value: "120+", icon: <Globe className="w-5 h-5 text-blue-400" /> },
        { label: "Uptime", value: "99.99%", icon: <TrendingUp className="w-5 h-5 text-emerald-400" /> },
    ];

    const values = [
        {
            title: "Transparency First",
            description: "We believe in complete transparency. Our real-time dashboards provide granular data on your mining performance and earnings.",
            icon: <Globe className="w-8 h-8 text-blue-400" />
        },
        {
            title: "Enterprise Grade Security",
            description: "Your assets are protected by military-grade encryption and cold storage solutions. We prioritize the security of your investments above all.",
            icon: <Shield className="w-8 h-8 text-emerald-400" />
        },
        {
            title: "Sustainable Mining",
            description: "We are committed to eco-friendly mining practices, utilizing 65% renewable energy sources across our global data centers.",
            icon: <Award className="w-8 h-8 text-yellow-400" />
        }
    ];

    return (
        <div className="container mx-auto px-4 py-20">
            {/* Hero Section */}
            <div className="text-center max-w-4xl mx-auto mb-20 space-y-8">
                <Badge variant="secondary" className="bg-violet-500/10 text-violet-300 border-violet-500/20 backdrop-blur-md px-4 py-1.5 text-sm">
                    About Us
                </Badge>
                <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight">
                    Democratizing the Future of <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-fuchsia-400">Crypto Mining</span>
                </h1>
                <p className="text-xl text-zinc-400 leading-relaxed max-w-2xl mx-auto">
                    We are building the most accessible, transparent, and efficient mining infrastructure in the world. Join us in securing the blockchain network.
                </p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
                {stats.map((stat, index) => (
                    <Card key={index} className="glass-card border-white/5 bg-zinc-900/50">
                        <CardContent className="p-6 text-center space-y-2">
                            <div className="flex justify-center mb-2 p-3 bg-white/5 rounded-full w-fit mx-auto border border-white/5">
                                {stat.icon}
                            </div>
                            <div className="text-3xl font-bold text-white">{stat.value}</div>
                            <div className="text-sm text-zinc-500">{stat.label}</div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Content Section */}
            <div className="grid lg:grid-cols-2 gap-16 items-center mb-24">
                <div className="space-y-8">
                    <h2 className="text-3xl font-bold text-white">Our Mission</h2>
                    <div className="space-y-6 text-lg text-zinc-400">
                        <p>
                            Founded in 2024, our mission is to remove the barriers to entry for cryptocurrency mining. We realized that setting up mining hardware, managing cooling, and handling maintenance was too complex for most people.
                        </p>
                        <p>
                            We built a platform where anyone can purchase mining power or hardware and start earning within minutes. We handle the infrastructure, so you can focus on the rewards.
                        </p>
                    </div>
                </div>
                <div className="relative aspect-square lg:aspect-video bg-gradient-to-br from-violet-900/20 to-zinc-900 rounded-3xl border border-white/10 overflow-hidden flex items-center justify-center">
                    <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-20" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                    {/* Abstract Hardware Representation */}
                    <div className="relative z-10 grid grid-cols-2 gap-4 opacity-80">
                        <div className="w-24 h-32 bg-zinc-800 rounded-lg border border-white/10 animate-pulse" style={{ animationDelay: '0s' }} />
                        <div className="w-24 h-32 bg-zinc-800 rounded-lg border border-white/10 animate-pulse" style={{ animationDelay: '0.2s' }} />
                        <div className="w-24 h-32 bg-zinc-800 rounded-lg border border-white/10 animate-pulse" style={{ animationDelay: '0.4s' }} />
                        <div className="w-24 h-32 bg-zinc-800 rounded-lg border border-white/10 animate-pulse" style={{ animationDelay: '0.6s' }} />
                    </div>
                </div>
            </div>

            {/* Values Section */}
            <div className="mb-12">
                <h2 className="text-3xl font-bold text-white text-center mb-12">Why Choose Us</h2>
                <div className="grid md:grid-cols-3 gap-8">
                    {values.map((value, index) => (
                        <Card key={index} className="glass-card border-white/5 hover:border-violet-500/20 transition-colors">
                            <CardContent className="p-8 space-y-4">
                                <div className="p-3 bg-white/5 rounded-xl w-fit border border-white/5">
                                    {value.icon}
                                </div>
                                <h3 className="text-xl font-bold text-white">{value.title}</h3>
                                <p className="text-zinc-400 leading-relaxed">
                                    {value.description}
                                </p>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            </div>
        </div>
    );
}
