"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, Server, Shield, Check, ArrowLeft, Cpu, Loader2 } from "lucide-react";
import Link from "next/link";
import { useAuthStore } from "@/store/authStore";
import apiClient from "@/lib/api";
import { toast } from "sonner";

interface Product {
    id: number;
    name: string;
    description: string;
    price: string;
    power_consumption: string;
    efficiency: string;
    daily_revenue: string;
    hosting_type: string;
    status: string;
    type?: string;
}

export default function ProductDetailPage() {
    const params = useParams();
    const router = useRouter();
    const { isAuthenticated } = useAuthStore();
    const [product, setProduct] = useState<Product | null>(null);
    const [loading, setLoading] = useState(true);
    const [purchasing, setPurchasing] = useState(false);

    useEffect(() => {
        const fetchProduct = async () => {
            try {
                // The API expects slug, but we might have ID in params if the previous page linked with ID
                // Ideally products should be linked by slug. Assuming ID for now based on current routing, 
                // but checking if we need to fetch by ID or slug. 
                // If params.id is numeric, it might be an ID. If string, it's slug.
                // The backend show method uses slug: Route::get('/products/{slug}', [ProductController::class, 'show']);
                // So we need to ensure we link with slug. 
                // For this fix, let's assume the param passed IS the slug.
                const response = await apiClient.get(`/products/${params.id}`);
                if (response.data.success) {
                    setProduct(response.data.data);
                }
            } catch (error) {
                console.error("Failed to fetch product:", error);
            } finally {
                setLoading(false);
            }
        };

        if (params.id) {
            fetchProduct();
        }
    }, [params.id]);

    const handleBuy = async () => {
        if (!isAuthenticated) {
            router.push("/login?redirect=/products/" + params.id);
            return;
        }
        setPurchasing(true);
        try {
            await apiClient.post('/purchases/buy', {
                product_id: product?.id,
                quantity: 1 // Default to 1 unit for now
            });
            toast.success("Purchase successful! Viewing your wallet...");
            router.push("/dashboard/wallet");
        } catch (error: any) {
            console.error("Purchase failed:", error);
            const message = error.response?.data?.message || "Purchase failed. Please check your wallet balance.";
            toast.error(message);
        } finally {
            setPurchasing(false);
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center min-h-screen">
                <Loader2 className="animate-spin text-zinc-500 w-8 h-8" />
            </div>
        );
    }

    if (!product) {
        return (
            <div className="container mx-auto px-4 py-20 text-center text-white">
                <h1 className="text-2xl font-bold">Product not found</h1>
                <Link href="/products" className="text-violet-400 hover:text-violet-300 mt-4 block">
                    Return to Products
                </Link>
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4 py-12 md:py-20">
            <Button variant="ghost" asChild className="mb-8 text-zinc-400 hover:text-white pl-0">
                <Link href="/products">
                    <ArrowLeft className="mr-2 w-4 h-4" /> Back to Products
                </Link>
            </Button>

            <div className="grid lg:grid-cols-2 gap-12 items-start">

                {/* Visual Section */}
                <div className="relative aspect-square lg:aspect-video bg-gradient-to-br from-zinc-900 to-black rounded-3xl border border-white/10 flex items-center justify-center overflow-hidden">
                    <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-20" />
                    <Cpu className="w-32 h-32 text-violet-500/50" />
                    <div className="absolute bottom-6 left-6 right-6">
                        <div className="flex gap-4">
                            <Badge variant="secondary" className="bg-violet-500/10 text-violet-300 border-violet-500/20 backdrop-blur-md">
                                ASIC Series
                            </Badge>
                            <Badge variant="secondary" className="bg-emerald-500/10 text-emerald-300 border-emerald-500/20 backdrop-blur-md capitalize">
                                {product.status}
                            </Badge>
                        </div>
                    </div>
                </div>

                {/* Details Section */}
                <div className="space-y-8">
                    <div>
                        <h1 className="text-4xl font-bold text-white mb-2">{product.name}</h1>
                        <div className="flex items-center gap-2 text-zinc-400">
                            {/* Hashrate might need to be parsed from description if not separate, 
                                 but we dont have hashrate column primarily. 
                                 However, we added short_description which usually contains hashrate info 
                                 or we can display efficiency.
                                 Let's use description or short_description. 
                             */}
                            <span className="text-xl font-medium text-white">
                                {product.efficiency || 'High Efficiency'}
                            </span>
                            <span>Efficiency</span>
                        </div>
                    </div>

                    <div className="flex items-baseline gap-2">
                        <span className="text-5xl font-bold text-white">${Number(product.price).toLocaleString()}</span>
                        <span className="text-lg text-zinc-500">USD</span>
                    </div>

                    <p className="text-lg text-zinc-400 leading-relaxed">
                        {product.description}
                    </p>

                    <div className="grid grid-cols-2 gap-4">
                        <SpecCard label="Power Consumption" value={product.power_consumption || 'N/A'} icon={<Zap className="w-4 h-4 text-yellow-400" />} />
                        <SpecCard label="Efficiency" value={product.efficiency || 'N/A'} icon={<Server className="w-4 h-4 text-blue-400" />} />
                        <SpecCard label="Est. Daily Revenue" value={product.daily_revenue || 'Calculating...'} icon={<Shield className="w-4 h-4 text-emerald-400" />} />
                        <SpecCard label="Hosting" value={product.hosting_type || 'Cloud'} icon={<Check className="w-4 h-4 text-white" />} />
                    </div>

                    <div className="pt-6 border-t border-white/10 space-y-4">
                        <Button
                            size="lg"
                            className="w-full h-14 text-lg bg-white text-black hover:bg-zinc-200"
                            onClick={handleBuy}
                            disabled={purchasing || product.status !== 'active'}
                        >
                            {purchasing ? "Processing..." : "Purchase Contract"}
                        </Button>
                        <p className="text-center text-xs text-zinc-500">
                            By purchasing, you agree to our Service Terms. Hosting fees apply automatically.
                        </p>
                    </div>

                </div>
            </div>
        </div>
    );
}

function SpecCard({ label, value, icon }: any) {
    return (
        <Card className="bg-white/5 border-white/5">
            <CardContent className="p-4 flex flex-col gap-1">
                <div className="flex items-center gap-2 text-zinc-400 text-sm">
                    {icon} {label}
                </div>
                <div className="text-lg font-semibold text-white">{value}</div>
            </CardContent>
        </Card>
    )
}
