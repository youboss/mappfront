"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, Server, TrendingUp, Info, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import apiClient from "@/lib/api";

interface Product {
    id: number;
    name: string;
    short_description: string;
    power_consumption: string;
    efficiency: string;
    daily_revenue: string;
    price: string;
    type: string; // Inferred
}

export default function ProductsPage() {
    const [products, setProducts] = useState<Product[]>([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState("ALL");

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await apiClient.get('/products');
                if (response.data.success) {
                    const fetchedProducts = response.data.data.data.map((p: any) => ({
                        ...p,
                        // Infer type if not present. 
                        type: p.name.toLowerCase().includes('cloud') || p.efficiency === 'Cloud' ? 'Cloud' : 'ASIC',
                        // Map short_description to hashrate visually if needed, but we can just use short_description directly
                    }));
                    setProducts(fetchedProducts);
                }
            } catch (error) {
                console.error("Failed to fetch products:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchProducts();
    }, []);

    const filteredProducts = filter === "ALL" ? products : products.filter(p => p.type === filter);

    if (loading) {
        return (
            <div className="flex justify-center items-center min-h-screen">
                <Loader2 className="animate-spin text-zinc-500 w-8 h-8" />
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4 py-16">
            <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
                <div className="space-y-2 text-center md:text-left">
                    <h1 className="text-4xl font-bold text-white tracking-tight">Mining Contracts</h1>
                    <p className="text-zinc-400 max-w-lg">Choose the perfect hardware or cloud plan to start your earning journey.</p>
                </div>

                <div className="flex p-1 bg-white/5 rounded-lg border border-white/5">
                    {["ALL", "ASIC", "Cloud"].map((type) => (
                        <button
                            key={type}
                            onClick={() => setFilter(type)}
                            className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${filter === type
                                ? "bg-violet-600 text-white shadow-lg shadow-violet-900/20"
                                : "text-zinc-400 hover:text-white"
                                }`}
                        >
                            {type}
                        </button>
                    ))}
                </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredProducts.map((product) => (
                    <motion.div
                        key={product.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3 }}
                    >
                        <Card className="glass-card border-white/5 h-full hover:border-violet-500/30 transition-all hover:-translate-y-1">
                            <CardHeader>
                                <div className="flex justify-between items-start mb-4">
                                    <Badge variant="outline" className="border-violet-500/30 text-violet-300 bg-violet-500/10 backdrop-blur-md">
                                        {product.type} Mining
                                    </Badge>
                                    <Zap className="w-5 h-5 text-yellow-400" />
                                </div>
                                <CardTitle className="text-2xl text-white">{product.name}</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <div className="flex items-end gap-2">
                                    <span className="text-3xl font-bold text-white">${Number(product.price).toLocaleString()}</span>
                                    <span className="text-zinc-500 mb-1">/ unit</span>
                                </div>

                                <div className="space-y-3">
                                    <div className="flex justify-between text-sm">
                                        <span className="text-zinc-400 flex items-center gap-2"><Server className="w-4 h-4" /> Hashrate</span>
                                        <span className="text-white font-medium">{product.short_description}</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-zinc-400 flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Est. Daily</span>
                                        <span className="text-emerald-400 font-medium">{product.daily_revenue || 'Calculating...'}</span>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <span className="text-zinc-400 flex items-center gap-2"><Info className="w-4 h-4" /> Efficiency</span>
                                        <span className="text-white font-medium">{product.efficiency || 'N/A'}</span>
                                    </div>
                                </div>
                            </CardContent>
                            <CardFooter>
                                <Link href={`/products/${product.id}`} className="w-full">
                                    <Button className="w-full bg-white text-black hover:bg-zinc-200">
                                        View Details
                                    </Button>
                                </Link>
                            </CardFooter>
                        </Card>
                    </motion.div>
                ))}
            </div>
        </div>
    );
}
