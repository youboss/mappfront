"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { motion } from "framer-motion";
import Link from "next/link";
import { ArrowRight, Zap, Shield, Globe, TrendingUp } from "lucide-react";

const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
};

const staggerContainer = {
    animate: {
        transition: {
            staggerChildren: 0.1
        }
    }
};

export default function LandingPage() {
    return (
        <div className="flex flex-col gap-20 pb-20 overflow-hidden">

            {/* Hero Section */}
            <section className="relative pt-20 md:pt-32 pb-32 overflow-visible">
                <div className="container px-4 md:px-6 mx-auto relative z-10">
                    <motion.div
                        initial="initial"
                        animate="animate"
                        variants={staggerContainer}
                        className="flex flex-col items-center text-center space-y-8"
                    >
                        <motion.div variants={fadeInUp} className="inline-flex items-center rounded-full border border-violet-500/30 bg-violet-500/10 px-3 py-1 text-sm font-medium text-violet-300 backdrop-blur-md">
                            <span className="flex h-2 w-2 rounded-full bg-violet-500 mr-2 animate-pulse"></span>
                            Next Gen Mining Protocol
                        </motion.div>

                        <motion.h1 variants={fadeInUp} className="text-4xl md:text-7xl font-bold tracking-tighter bg-clip-text text-transparent bg-gradient-to-b from-white via-white to-white/40 max-w-4xl">
                            Unlock the Future of <br className="hidden md:block" />
                            <span className="text-violet-400">Sustainable Wealth</span>
                        </motion.h1>

                        <motion.p variants={fadeInUp} className="text-lg md:text-xl text-muted-foreground max-w-[700px]">
                            Access enterprise-grade crypto mining infrastructure with zero hardware management.
                            Secure, transparent, and built for maximum yield.
                        </motion.p>

                        <motion.div variants={fadeInUp} className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
                            <Link href="/register">
                                <Button size="lg" variant="gradient" className="w-full sm:w-auto h-12 px-8 text-base">
                                    Start Mining Now
                                    <ArrowRight className="ml-2 w-4 h-4" />
                                </Button>
                            </Link>
                            <Link href="/products">
                                <Button size="lg" variant="glass" className="w-full sm:w-auto h-12 px-8 text-base text-white">
                                    View Contracts
                                </Button>
                            </Link>
                        </motion.div>
                    </motion.div>
                </div>

                {/* Ambient Spline Background Effect - Simplified for performace */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-[1200px] pointer-events-none opacity-40 z-0">
                    <div className="absolute top-[20%] left-[20%] w-[300px] h-[300px] bg-violet-600/30 rounded-full blur-[100px]" />
                    <div className="absolute top-[30%] right-[20%] w-[400px] h-[400px] bg-indigo-600/20 rounded-full blur-[120px]" />
                </div>
            </section>

            {/* Stats Section */}
            <section className="container px-4 mx-auto">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 rounded-2xl border border-white/5 bg-white/5 p-8 backdrop-blur-xl">
                    {[
                        { label: "Total Value Locked", value: "$42.5M+" },
                        { label: "Active Miners", value: "12,450" },
                        { label: "Hashrate", value: "850 PH/s" },
                        { label: "Uptime", value: "99.99%" },
                    ].map((stat, i) => (
                        <div key={i} className="flex flex-col items-center justify-center text-center">
                            <div className="text-2xl md:text-3xl font-bold text-white mb-1">{stat.value}</div>
                            <div className="text-sm text-muted-foreground">{stat.label}</div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Features Grid */}
            <section className="container px-4 mx-auto">
                <div className="space-y-4 text-center mb-16">
                    <h2 className="text-3xl font-bold tracking-tighter text-white">Why Choose MineFi?</h2>
                    <p className="text-muted-foreground">Built for investors who demand performance and security.</p>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                    <FeatureCard
                        icon={<Zap className="w-6 h-6 text-yellow-400" />}
                        title="Instant Activation"
                        description="Start earning immediately after purchase. No hardware setup or shipping delays."
                    />
                    <FeatureCard
                        icon={<Shield className="w-6 h-6 text-emerald-400" />}
                        title="Bank-Grade Security"
                        description="Assets secured by multi-sig wallets and regular third-party audits."
                    />
                    <FeatureCard
                        icon={<TrendingUp className="w-6 h-6 text-violet-400" />}
                        title="Daily Payouts"
                        description="Earnings credited to your wallet every 24 hours. Withdraw anytime."
                    />
                </div>
            </section>

            {/* Trust Section */}
            <section className="container px-4 mx-auto mb-20">
                <div className="rounded-3xl bg-gradient-to-r from-violet-900/50 to-indigo-900/50 border border-white/10 p-8 md:p-16 text-center relative overflow-hidden">
                    <div className="absolute inset-0 bg-grid-white/[0.02]" />
                    <div className="relative z-10 max-w-2xl mx-auto space-y-6">
                        <h2 className="text-3xl font-bold text-white">Ready to Transform Your Portfolio?</h2>
                        <p className="text-violet-200">Join the fastest growing mining community and start earning passive income today.</p>
                        <div className="pt-4">
                            <Link href="/register">
                                <Button size="lg" className="bg-white text-violet-900 hover:bg-gray-100 shadow-xl shadow-violet-900/20 px-8 py-6 text-lg font-semibold">
                                    Create Free Account
                                </Button>
                            </Link>
                        </div>
                    </div>
                </div>
            </section>

        </div>
    );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
    return (
        <Card className="border-white/5 bg-white/5 hover:bg-white/10 transition-colors duration-300">
            <CardHeader>
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mb-4 border border-white/10">
                    {icon}
                </div>
                <CardTitle className="text-xl text-white font-semibold bg-none text-transparent bg-clip-text">{title}</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                    {description}
                </p>
            </CardContent>
        </Card>
    );
}
