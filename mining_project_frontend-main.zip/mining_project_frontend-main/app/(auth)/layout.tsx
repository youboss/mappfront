export default function AuthLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <div className="min-h-screen grid lg:grid-cols-2">
            {/* Narrative Section (Hidden on mobile) */}
            <div className="hidden lg:flex flex-col justify-between bg-zinc-900 p-10 text-white relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-violet-900/40 via-zinc-900 to-black z-0" />
                <div className="absolute top-0 left-0 w-full h-full bg-[url('/grid.svg')] opacity-20 z-0" />

                <div className="relative z-10 flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-violet-600 to-indigo-600 flex items-center justify-center">
                        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    </div>
                    <span className="text-xl font-bold">MineFi</span>
                </div>

                <div className="relative z-10 max-w-lg">
                    <blockquote className="space-y-2">
                        <p className="text-lg">
                            &ldquo;MineFi has completely transformed how I approach crypto mining. The transparency and ease of use are unmatched in the industry.&rdquo;
                        </p>
                        <footer className="text-sm text-zinc-400">Sofia Davis, Early Investor</footer>
                    </blockquote>
                </div>
            </div>

            {/* Form Section */}
            <div className="flex items-center justify-center p-8 bg-black relative">
                {/* Mobile Background Effect */}
                <div className="absolute inset-0 z-0 lg:hidden bg-gradient-to-b from-zinc-900 to-black" />

                <div className="w-full max-w-md relative z-10">
                    {children}
                </div>
            </div>
        </div>
    );
}
