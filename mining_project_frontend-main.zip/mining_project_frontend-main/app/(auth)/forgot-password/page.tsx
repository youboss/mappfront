"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import apiClient, { getCsrfCookie } from "@/lib/api";
import { ArrowLeft, Mail, Loader2 } from "lucide-react";

export default function ForgotPasswordPage() {
    const [email, setEmail] = useState("");
    const [loading, setLoading] = useState(false);
    const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
    const [message, setMessage] = useState("");

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setStatus("idle");
        setMessage("");

        try {
            await getCsrfCookie();
            const response = await apiClient.post("/forgot-password", { email });
            setStatus("success");
            setMessage(response.data.message || "Password reset link sent! Please check your email.");
        } catch (err: any) {
            console.error("Forgot password request failed", err);
            setStatus("error");
            setMessage(err.response?.data?.message || "Something went wrong. Please try again later.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card className="glass-card border-white/10 shadow-2xl relative overflow-hidden">
            <CardHeader className="space-y-1">
                <div className="flex justify-center mb-4">
                    <div className="p-3 rounded-full bg-violet-600/10 border border-violet-500/20">
                        <Mail className="w-6 h-6 text-violet-400" />
                    </div>
                </div>
                <CardTitle className="text-2xl text-center text-white">Forgot password?</CardTitle>
                <CardDescription className="text-center text-zinc-400">
                    No worries, we&apos;ll send you reset instructions.
                </CardDescription>
            </CardHeader>
            <CardContent>
                {status === "success" ? (
                    <div className="space-y-4">
                        <div className="p-4 text-sm text-emerald-400 bg-emerald-900/20 border border-emerald-900/50 rounded-lg text-center">
                            {message}
                        </div>
                        <Button asChild className="w-full bg-zinc-800 hover:bg-zinc-700 text-white">
                            <Link href="/login">
                                <ArrowLeft className="w-4 h-4 mr-2" />
                                Back to login
                            </Link>
                        </Button>
                    </div>
                ) : (
                    <form onSubmit={handleSubmit} className="space-y-4">
                        {status === "error" && (
                            <div className="p-3 text-sm text-red-400 bg-red-900/20 border border-red-900/50 rounded-md text-center">
                                {message}
                            </div>
                        )}

                        <div className="space-y-2">
                            <Label htmlFor="email" className="text-zinc-300">Email Address</Label>
                            <Input
                                id="email"
                                type="email"
                                placeholder="Enter your email"
                                className="bg-zinc-900/50 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-violet-500"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>

                        <Button type="submit" className="w-full bg-violet-600 hover:bg-violet-700 text-white" disabled={loading}>
                            {loading ? (
                                <>
                                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                    Sending Link...
                                </>
                            ) : (
                                "Reset Password"
                            )}
                        </Button>
                    </form>
                )}
            </CardContent>
            {status !== "success" && (
                <CardFooter className="flex justify-center">
                    <Link href="/login" className="text-sm text-zinc-400 hover:text-white flex items-center transition-colors">
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Back to login
                    </Link>
                </CardFooter>
            )}
        </Card>
    );
}
