"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import apiClient, { getCsrfCookie } from "@/lib/api";

export default function RegisterPage() {
    const router = useRouter();
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        password: "",
        password_confirmation: ""
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError("");

        try {
            // 1. Get CSRF cookie first (Sanctum SPA authentication)
            await getCsrfCookie();

            // 2. Register
            await apiClient.post('/register', formData);

            // 3. Redirect to login (or auto-login)
            router.push("/login?registered=true");
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
        } catch (err: any) {
            setError(err.response?.data?.message || "Registration failed. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card className="glass-card border-white/10 shadow-2xl">
            <CardHeader className="space-y-1">
                <CardTitle className="text-2xl text-center text-white">Create an account</CardTitle>
                <CardDescription className="text-center text-zinc-400">
                    Enter your details below to start your mining journey
                </CardDescription>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                    {error && (
                        <div className="p-3 text-sm text-red-400 bg-red-900/20 border border-red-900/50 rounded-md">
                            {error}
                        </div>
                    )}

                    <div className="space-y-2">
                        <Label htmlFor="name" className="text-zinc-300">Full Name</Label>
                        <Input
                            id="name"
                            placeholder="John Doe"
                            className="bg-zinc-900/50 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-violet-500"
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            required
                        />
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="email" className="text-zinc-300">Email</Label>
                        <Input
                            id="email"
                            type="email"
                            placeholder="m@example.com"
                            className="bg-zinc-900/50 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-violet-500"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            required
                        />
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="password" className="text-zinc-300">Password</Label>
                        <Input
                            id="password"
                            type="password"
                            className="bg-zinc-900/50 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-violet-500"
                            value={formData.password}
                            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                            required
                        />
                        <p className="text-[10px] text-zinc-500 mt-1">
                            Min 8 chars, mixed case, numbers & symbols.
                        </p>
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="password_confirmation" className="text-zinc-300">Confirm Password</Label>
                        <Input
                            id="password_confirmation"
                            type="password"
                            className="bg-zinc-900/50 border-zinc-700 text-white placeholder:text-zinc-500 focus:ring-violet-500"
                            value={formData.password_confirmation}
                            onChange={(e) => setFormData({ ...formData, password_confirmation: e.target.value })}
                            required
                        />
                    </div>

                    <Button type="submit" className="w-full bg-violet-600 hover:bg-violet-700 text-white" disabled={loading}>
                        {loading ? "Creating account..." : "Create account"}
                    </Button>
                </form>

                <div className="mt-4 relative">
                    <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t border-zinc-800" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-black px-2 text-zinc-500">Or continue with</span>
                    </div>
                </div>


            </CardContent>
            <CardFooter className="flex flex-col space-y-2 text-center text-sm text-zinc-400">
                <div>
                    Already have an account?{" "}
                    <Link href="/login" className="underline underline-offset-4 hover:text-white text-violet-400">
                        Sign in
                    </Link>
                </div>
            </CardFooter>
        </Card>
    );
}
