"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import apiClient from "@/lib/api";
import { KeyRound, Loader2, CheckCircle2 } from "lucide-react";

function ResetPasswordForm() {
    const router = useRouter();
    const searchParams = useSearchParams();

    const [token, setToken] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [passwordConfirmation, setPasswordConfirmation] = useState("");
    const [loading, setLoading] = useState(false);
    const [status, setStatus] = useState<"idle" | "success" | "error">("idle");
    const [message, setMessage] = useState("");

    useEffect(() => {
        const tokenParam = searchParams.get("token");
        const emailParam = searchParams.get("email");

        if (tokenParam) setToken(tokenParam);
        if (emailParam) setEmail(emailParam);

        if (!tokenParam || !emailParam) {
            setStatus("error");
            setMessage("Invalid or missing reset link parameters.");
        }
    }, [searchParams]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (password !== passwordConfirmation) {
            setStatus("error");
            setMessage("Passwords do not match.");
            return;
        }

        setLoading(true);
        setStatus("idle");
        setMessage("");

        try {
            const response = await apiClient.post("/reset-password", {
                token,
                email,
                password,
                password_confirmation: passwordConfirmation,
            });
            setStatus("success");
            setMessage(response.data.message || "Password reset successfully!");

            // Redirect to login after 3 seconds
            setTimeout(() => {
                router.push("/login");
            }, 3000);
        } catch (err: any) {
            console.error("Password reset failed", err);
            setStatus("error");
            setMessage(err.response?.data?.message || "Failed to reset password. The link may have expired.");
        } finally {
            setLoading(false);
        }
    };

    if (status === "success") {
        return (
            <div className="space-y-6 py-4 text-center">
                <div className="flex justify-center">
                    <CheckCircle2 className="w-16 h-16 text-emerald-500 animate-in zoom-in duration-500" />
                </div>
                <div className="space-y-2">
                    <h3 className="text-xl font-bold text-white">Password Reset!</h3>
                    <p className="text-zinc-400">Your password has been successfully updated. Redirecting you to login...</p>
                </div>
                <Button asChild className="w-full bg-violet-600 hover:bg-violet-700 text-white">
                    <Link href="/login">Go to Login</Link>
                </Button>
            </div>
        );
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            {status === "error" && (
                <div className="p-3 text-sm text-red-400 bg-red-900/20 border border-red-900/50 rounded-md text-center">
                    {message}
                </div>
            )}

            <div className="space-y-2">
                <Label htmlFor="email" className="text-zinc-300">Email Address</Label>
                <Input
                    id="email"
                    type="email"
                    value={email}
                    disabled
                    className="bg-zinc-900/50 border-zinc-700 text-zinc-400 cursor-not-allowed"
                />
            </div>

            <div className="space-y-2">
                <Label htmlFor="password" className="text-zinc-300">New Password</Label>
                <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    className="bg-zinc-900/50 border-zinc-700 text-white focus:ring-violet-500"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
            </div>

            <div className="space-y-2">
                <Label htmlFor="password_confirmation" className="text-zinc-300">Confirm New Password</Label>
                <Input
                    id="password_confirmation"
                    type="password"
                    placeholder="••••••••"
                    className="bg-zinc-900/50 border-zinc-700 text-white focus:ring-violet-500"
                    value={passwordConfirmation}
                    onChange={(e) => setPasswordConfirmation(e.target.value)}
                    required
                />
            </div>

            <Button type="submit" className="w-full bg-violet-600 hover:bg-violet-700 text-white" disabled={loading || !token}>
                {loading ? (
                    <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Resetting Password...
                    </>
                ) : (
                    "Reset Password"
                )}
            </Button>
        </form>
    );
}

export default function ResetPasswordPage() {
    return (
        <Card className="glass-card border-white/10 shadow-2xl">
            <CardHeader className="space-y-1">
                <div className="flex justify-center mb-4">
                    <div className="p-3 rounded-full bg-violet-600/10 border border-violet-500/20">
                        <KeyRound className="w-6 h-6 text-violet-400" />
                    </div>
                </div>
                <CardTitle className="text-2xl text-center text-white">Set new password</CardTitle>
                <CardDescription className="text-center text-zinc-400">
                    Choose a strong password to protect your account.
                </CardDescription>
            </CardHeader>
            <CardContent>
                <Suspense fallback={
                    <div className="flex justify-center items-center py-10">
                        <Loader2 className="w-8 h-8 text-violet-500 animate-spin" />
                    </div>
                }>
                    <ResetPasswordForm />
                </Suspense>
            </CardContent>
        </Card>
    );
}
