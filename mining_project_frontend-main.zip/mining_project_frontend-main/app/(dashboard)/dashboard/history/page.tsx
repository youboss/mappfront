"use client";

import { useAuthStore } from "@/store/authStore";
import apiClient from "@/lib/api";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge"; // Need to ensure Badge exists or use raw span
import { Zap, Clock, CheckCircle } from "lucide-react";

export default function HistoryPage() {
    const { isAuthenticated } = useAuthStore();
    const router = useRouter();
    const [purchases, setPurchases] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!isAuthenticated) {
            router.push("/login");
            return;
        }

        const fetchPurchases = async () => {
            try {
                // Determine API base URL dynamically or fallback to relative path if proxied
                // But we have apiClient configured
                const response = await apiClient.get('/purchases');

                if (response.data.success) {
                    const mappedPurchases = response.data.data.data.map((purchase: any) => ({
                        id: `ORD-${purchase.id.toString().padStart(4, '0')}`,
                        product: purchase.product?.name || 'Unknown Product',
                        hashrate: "N/A", // Placeholder as per schema
                        price: purchase.total_amount,
                        status: purchase.status,
                        date: new Date(purchase.created_at).toLocaleDateString(),
                        dailyYield: "N/A" // Placeholder as per schema
                    }));
                    setPurchases(mappedPurchases);
                }
            } catch (error) {
                console.error("Failed to fetch purchases:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchPurchases();
    }, [isAuthenticated, router]);

    if (loading) {
        return (
            <div className="flex justify-center items-center py-20">
                <div className="text-zinc-400 animate-pulse">Loading history...</div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-white tracking-tight">Mining Contracts</h1>
                <p className="text-zinc-400">Track the performance and status of your purchased hardware.</p>
            </div>

            <div className="grid gap-4">
                {purchases.length === 0 ? (
                    <div className="text-center py-10 text-zinc-500">
                        No purchase history found.
                    </div>
                ) : (
                    purchases.map((purchase: any) => (
                        <Card key={purchase.id} className="glass-card border-white/5 hover:border-violet-500/30 transition-all group">
                            <CardContent className="p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                                <div className="flex items-center gap-4">
                                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center border border-white/10 ${purchase.status === 'completed' || purchase.status === 'active' ? 'bg-violet-500/10 text-violet-400' : 'bg-zinc-800 text-zinc-500'}`}>
                                        <Zap className="w-6 h-6" />
                                    </div>
                                    <div>
                                        <h3 className="text-lg font-bold text-white group-hover:text-violet-300 transition-colors">{purchase.product}</h3>
                                        <div className="flex items-center gap-2 text-sm text-zinc-500">
                                            <span>{purchase.hashrate}</span>
                                            <span>•</span>
                                            <span>Purchased: {purchase.date}</span>
                                        </div>
                                    </div>
                                </div>

                                <div className="flex flex-wrap items-center gap-4 md:gap-12 w-full md:w-auto">
                                    <div>
                                        <div className="text-sm text-zinc-500">Daily Yield</div>
                                        <div className="text-white font-medium">{purchase.dailyYield}</div>
                                    </div>
                                    <div>
                                        <div className="text-sm text-zinc-500">Total Price</div>
                                        <div className="text-white font-medium">${purchase.price}</div>
                                    </div>
                                    <div>
                                        <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${purchase.status === 'completed' || purchase.status === 'active'
                                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                            : 'bg-zinc-500/10 text-zinc-400 border border-zinc-500/20'
                                            }`}>
                                            {purchase.status}
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))
                )}
            </div>
        </div>
    );
}
