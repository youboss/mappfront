"use client";

import { useAuthStore } from "@/store/authStore";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Mail, Shield, Calendar } from "lucide-react";

export default function ProfilePage() {
    const { user, isAuthenticated } = useAuthStore();
    const router = useRouter();

    useEffect(() => {
        if (!isAuthenticated) {
            router.push("/login");
        }
    }, [isAuthenticated, router]);

    if (!user) {
        return null; // Or a loading spinner
    }

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-white tracking-tight">Profile</h1>
                <p className="text-zinc-400">Manage your account information.</p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
                <Card className="glass-card border-white/5 md:col-span-2">
                    <CardHeader>
                        <CardTitle className="text-white">Personal Information</CardTitle>
                        <CardDescription>Your account details and verification status.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="flex items-center gap-6">
                            <div className="h-20 w-20 rounded-full border-2 border-violet-500/20 overflow-hidden bg-violet-600 flex items-center justify-center">
                                {user.avatar ? (
                                    <img src={user.avatar} alt={user.name} className="h-full w-full object-cover" />
                                ) : (
                                    <span className="text-white text-3xl font-medium">{user.name?.charAt(0).toUpperCase()}</span>
                                )}
                            </div>
                            <div className="space-y-1">
                                <h3 className="text-xl font-medium text-white">{user.name}</h3>
                                <p className="text-zinc-400 flex items-center gap-2">
                                    <Mail className="w-4 h-4" /> {user.email}
                                </p>
                                <div className="flex items-center gap-2 mt-2">
                                    <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 capitalize">
                                        <Shield className="w-3 h-3 mr-1" />
                                        {user.roles?.[0]?.name || 'User'}
                                    </Badge>
                                </div>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="glass-card border-white/5">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Shield className="w-5 h-5 text-violet-400" /> Account Security
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                            <span className="text-zinc-400">Password</span>
                            <span className="text-white">••••••••</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                            <span className="text-zinc-400">2FA Status</span>
                            <span className="text-zinc-500 italic">Not enabled</span>
                        </div>
                    </CardContent>
                </Card>

                <Card className="glass-card border-white/5">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center gap-2">
                            <Calendar className="w-5 h-5 text-indigo-400" /> Account History
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                            <span className="text-zinc-400">Joined</span>
                            <span className="text-white">{new Date(user.created_at || Date.now()).toLocaleDateString()}</span>
                        </div>
                        <div className="flex justify-between items-center py-2 border-b border-white/5">
                            <span className="text-zinc-400">Status</span>
                            <Badge className="bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20">Active</Badge>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
