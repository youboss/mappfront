"use client";

import { useAuthStore } from "@/store/authStore";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, CreditCard, HardDrive, ShieldCheck, TrendingUp, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { motion } from "framer-motion";

import apiClient from "@/lib/api";
import { useState } from "react";

interface DashboardData {
    total_balance: number;
    active_contracts: number;
    est_daily_yield: number;
    total_paid_out: number;
    recent_transactions: any[];
    mining_history: { date: string; amount: number }[];
    currency: string;
}

import {
    AreaChart,
    Area,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer
} from 'recharts';

export default function DashboardPage() {
    const { user, isAuthenticated, isAdmin } = useAuthStore();
    const router = useRouter();
    const [stats, setStats] = useState<DashboardData | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!isAuthenticated) {
            router.push("/login");
            return;
        }

        const fetchDashboard = async () => {
            try {
                const res = await apiClient.get('/dashboard');
                if (res.data.success) {
                    setStats(res.data.data);
                }
            } catch (error) {
                console.error("Failed to fetch dashboard data", error);
            } finally {
                setLoading(false);
            }
        };

        fetchDashboard();
    }, [isAuthenticated, router]);

    if (!user) return null;

    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white tracking-tight">Dashboard</h1>
                    <p className="text-zinc-400">Welcome back, here's your mining overview.</p>
                </div>
                <div className="flex flex-wrap gap-3">
                    {isAdmin() && (
                        <Link href="/admin">
                            <Button variant="outline" className="border-emerald-500/30 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 hover:text-emerald-300">
                                <ShieldCheck className="mr-2 w-4 h-4" />
                                Admin Panel
                            </Button>
                        </Link>
                    )}
                    <Link href="/products">
                        <Button variant="gradient" className="shadow-lg shadow-violet-900/20">
                            <Zap className="mr-2 w-4 h-4" />
                            Buy Hashrate
                        </Button>
                    </Link>
                    <Link href="/dashboard/wallet">
                        <Button variant="outline" className="border-zinc-700 bg-zinc-900/50 hover:bg-zinc-800">
                            <CreditCard className="mr-2 w-4 h-4" />
                            Deposit
                        </Button>
                    </Link>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <StatCard
                    title="Total Balance"
                    value={`$${Number(stats?.total_balance || 0).toFixed(2)}`}
                    subvalue={`≈ ${Number(stats?.total_balance || 0) / 95000} BTC`} // Mock BTC calculation
                    icon={<CreditCard className="w-5 h-5 text-violet-400" />}
                    trend="+0%"
                />
                <StatCard
                    title="Active Contracts"
                    value={stats?.active_contracts || 0}
                    subvalue="Mining Contracts"
                    icon={<HardDrive className="w-5 h-5 text-emerald-400" />}
                    trend="+0%"
                />
                <StatCard
                    title="Est. Daily Yield"
                    value={`$${Number(stats?.est_daily_yield || 0).toFixed(2)}`}
                    subvalue={`≈ ${Number(stats?.est_daily_yield || 0) / 95000} BTC`}
                    icon={<Activity className="w-5 h-5 text-indigo-400" />}
                    trend="+0%"
                />
                <StatCard
                    title="Total Paid Out"
                    value={`$${Number(stats?.total_paid_out || 0).toFixed(2)}`}
                    subvalue="Lifetime Earnings"
                    icon={<TrendingUp className="w-5 h-5 text-amber-400" />}
                />
            </div>

            {/* Recent Activity / Charts Placeholder */}
            <div className="grid gap-4 md:grid-cols-7">
                <Card className="glass-card md:col-span-4 border-white/5">
                    <CardHeader>
                        <CardTitle className="text-white text-lg">Mining Performance</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="h-[300px] w-full">
                            {stats?.mining_history ? (
                                <ResponsiveContainer width="100%" height="100%">
                                    <AreaChart data={stats.mining_history} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                                        <defs>
                                            <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                                                <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                                            </linearGradient>
                                        </defs>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                                        <XAxis
                                            dataKey="date"
                                            axisLine={false}
                                            tickLine={false}
                                            tick={{ fill: '#71717a', fontSize: 12 }}
                                            dy={10}
                                        />
                                        <YAxis
                                            axisLine={false}
                                            tickLine={false}
                                            tick={{ fill: '#71717a', fontSize: 12 }}
                                        />
                                        <Tooltip
                                            contentStyle={{
                                                backgroundColor: '#18181b',
                                                border: '1px solid rgba(255,255,255,0.1)',
                                                borderRadius: '8px',
                                                color: '#fff'
                                            }}
                                            itemStyle={{ color: '#a78bfa' }}
                                        />
                                        <Area
                                            type="monotone"
                                            dataKey="amount"
                                            stroke="#8b5cf6"
                                            strokeWidth={2}
                                            fillOpacity={1}
                                            fill="url(#colorAmount)"
                                        />
                                    </AreaChart>
                                </ResponsiveContainer>
                            ) : (
                                <div className="h-full flex items-center justify-center border border-dashed border-zinc-800 rounded-lg bg-black/20">
                                    <p className="text-zinc-500 text-sm">Loading performance data...</p>
                                </div>
                            )}
                        </div>
                    </CardContent>
                </Card>
                <Card className="glass-card md:col-span-3 border-white/5">
                    <CardHeader>
                        <CardTitle className="text-white text-lg">Recent Transactions</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {!stats?.recent_transactions || stats.recent_transactions.length === 0 ? (
                                <div className="text-center py-8 text-zinc-500 text-sm">
                                    No recent activity
                                </div>
                            ) : (
                                stats.recent_transactions.map((tx: any) => (
                                    <div key={tx.id} className="flex justify-between items-center border-b border-white/5 last:border-0 pb-2 last:pb-0">
                                        <div>
                                            <p className="text-zinc-300 text-sm font-medium">{tx.description}</p>
                                            <p className="text-zinc-500 text-xs">{new Date(tx.created_at).toLocaleDateString()}</p>
                                        </div>
                                        <span className={`text-sm font-bold ${tx.type === 'credit' ? 'text-emerald-400' : 'text-zinc-300'}`}>
                                            {tx.type === 'credit' ? '+' : '-'}${Number(tx.amount).toFixed(2)}
                                        </span>
                                    </div>
                                ))
                            )}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

function StatCard({ title, value, subvalue, icon, trend }: any) {
    return (
        <Card className="glass-card border-white/5 hover:border-white/10 transition-colors">
            <CardContent className="p-6">
                <div className="flex items-center justify-between space-y-0 pb-2">
                    <p className="text-sm font-medium text-zinc-400">{title}</p>
                    <div className="p-2 rounded-lg bg-white/5 border border-white/5">
                        {icon}
                    </div>
                </div>
                <div className="flex flex-col gap-1">
                    <div className="text-2xl font-bold text-white">{value}</div>
                    <p className="text-xs text-zinc-500">{subvalue}</p>
                </div>
            </CardContent>
        </Card>
    )
}
