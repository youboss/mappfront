"use client";

import { useAuthStore } from "@/store/authStore";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ArrowDownLeft, ArrowUpRight, Wallet, History as HistoryIcon } from "lucide-react";
import { toast } from "sonner";

import apiClient from "@/lib/api";

interface Transaction {
    id: string; // UUID
    type: string;
    amount: number; // string or number depending on casting, but likely number if casted in model
    description: string;
    created_at: string;
    balance_after: string;
}

export default function WalletPage() {
    const { isAuthenticated } = useAuthStore();
    const router = useRouter();
    const [balance, setBalance] = useState({ available: 0, frozen: 0 });
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [loading, setLoading] = useState(true);
    const [withdrawalAmount, setWithdrawalAmount] = useState('');
    const [withdrawalAddress, setWithdrawalAddress] = useState('');
    const [submitting, setSubmitting] = useState(false);

    const [depositAddress, setDepositAddress] = useState<string | null>(null);
    const [generatingAddress, setGeneratingAddress] = useState(false);
    const [depositAmount, setDepositAmount] = useState('');
    const [proofFile, setProofFile] = useState<File | null>(null);

    const handleGenerateAddress = async () => {
        setGeneratingAddress(true);
        try {
            const res = await apiClient.get('/wallet/deposit-address');
            if (res.data.success) {
                setDepositAddress(res.data.data.address);
            }
        } catch (error) {
            console.error('Failed to generate address', error);
            toast.error('Failed to generate deposit address. Please try again.');
        } finally {
            setGeneratingAddress(false);
        }
    };

    const handleDeposit = async () => {
        if (!depositAmount || !proofFile) {
            toast.error("Please enter amount and upload payment proof.");
            return;
        }

        setSubmitting(true);
        const formData = new FormData();
        formData.append('amount', depositAmount);
        formData.append('payment_proof', proofFile);

        try {
            const res = await apiClient.post('/wallet/request', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            if (res.data.success) {
                toast.success('Deposit request submitted successfully! Pending approval.');
                setDepositAmount('');
                setProofFile(null);
                setDepositAddress(null); // Reset to allow new request
            }
        } catch (error: any) {
            toast.error(error.response?.data?.message || 'Failed to submit deposit request');
        } finally {
            setSubmitting(false);
        }
    };

    const handleWithdrawal = async () => {
        if (!withdrawalAmount || !withdrawalAddress) return;
        setSubmitting(true);
        try {
            const res = await apiClient.post('/wallet/withdraw', {
                amount: withdrawalAmount,
                withdrawal_address: withdrawalAddress
            });
            if (res.data.success) {
                toast.success('Withdrawal request submitted successfully! Pending approval.');
                setWithdrawalAmount('');
                setWithdrawalAddress('');
                // Optionally refresh transactions/requests list (not yet implemented in UI view)
            }
        } catch (error: any) {
            toast.error(error.response?.data?.message || 'Failed to submit withdrawal request');
        } finally {
            setSubmitting(false);
        }
    };

    useEffect(() => {
        if (!isAuthenticated) {
            router.push("/login");
            return;
        }

        const fetchData = async () => {
            try {
                const [balanceRes, transactionsRes] = await Promise.all([
                    apiClient.get('/wallet/balance'),
                    apiClient.get('/wallet/transactions')
                ]);

                if (balanceRes.data.success) {
                    setBalance({
                        available: Number(balanceRes.data.data.balance),
                        frozen: 0
                    });
                }

                if (transactionsRes.data.success) {
                    setTransactions(transactionsRes.data.data.data); // data.data because of pagination
                }
            } catch (error) {
                console.error("Failed to fetch wallet data:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [isAuthenticated, router]);

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-white tracking-tight">Wallet</h1>
                <p className="text-zinc-400">Manage your funds and view transaction history.</p>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
                {/* Balance Card */}
                <Card className="md:col-span-1 glass-card border-violet-500/20 bg-gradient-to-br from-violet-900/10 to-indigo-900/10">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-zinc-300 font-medium text-sm">
                            <Wallet className="w-4 h-4" /> Available Balance
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="text-4xl font-bold text-white tracking-tight">
                            ${balance.available.toFixed(2)}
                        </div>
                        <div className="text-xs text-zinc-500 mt-1">
                            ≈ {(balance.available / 95000).toFixed(8)} BTC
                        </div>
                        <div className="mt-6 flex space-x-2">
                            <Button className="flex-1 bg-white text-black hover:bg-zinc-200">
                                <ArrowDownLeft className="mr-2 w-4 h-4" /> Deposit
                            </Button>
                            <Button variant="outline" className="flex-1 border-white/10 text-white hover:bg-white/10">
                                <ArrowUpRight className="mr-2 w-4 h-4" /> Withdraw
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                {/* Operations Panel */}
                <Card className="md:col-span-2 glass-card border-white/5">
                    <CardHeader>
                        <CardTitle className="text-white">Quick Actions</CardTitle>
                        <CardDescription>Securely manage your assets.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Tabs defaultValue="deposit" className="w-full">
                            <TabsList className="bg-zinc-900/50 border border-white/5 w-full md:w-auto grid grid-cols-2 md:inline-flex">
                                <TabsTrigger value="deposit">Deposit</TabsTrigger>
                                <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
                            </TabsList>
                            <TabsContent value="deposit" className="space-y-4 mt-4">
                                <div className="space-y-2">
                                    <Label htmlFor="amount" className="text-zinc-300">Amount (USDT)</Label>
                                    <div className="relative">
                                        <span className="absolute left-3 top-2.5 text-zinc-500">$</span>
                                        <Input
                                            id="amount"
                                            type="number"
                                            placeholder="0.00"
                                            className="pl-7 bg-black/20 border-white/10 text-white"
                                            value={depositAmount}
                                            onChange={(e) => setDepositAmount(e.target.value)}
                                        />
                                    </div>
                                </div>
                                <div className="p-4 rounded-lg bg-yellow-900/10 border border-yellow-500/20 text-yellow-200 text-sm">
                                    Funds will be credited after 3 network confirmations. Please ensure you send TRC20 USDT.
                                </div>

                                {depositAddress ? (
                                    <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2">
                                        <div className="space-y-2">
                                            <Label className="text-zinc-300">Deposit Address (TRC20)</Label>
                                            <div className="flex gap-2">
                                                <Input
                                                    readOnly
                                                    value={depositAddress}
                                                    className="bg-black/20 border-white/10 text-white font-mono text-sm"
                                                />
                                                <Button
                                                    variant="outline"
                                                    className="border-white/10 text-white hover:bg-white/10"
                                                    onClick={() => {
                                                        navigator.clipboard.writeText(depositAddress);
                                                        toast.success('Address copied to clipboard!');
                                                    }}
                                                >
                                                    Copy
                                                </Button>
                                            </div>
                                            <p className="text-xs text-zinc-500 text-center">
                                                Send only USDT TRC20. Sending any other asset may result in permanent loss.
                                            </p>
                                        </div>

                                        <div className="space-y-2">
                                            <Label htmlFor="proof" className="text-zinc-300">Payment Proof (Screenshot)</Label>
                                            <Input
                                                id="proof"
                                                type="file"
                                                accept="image/*"
                                                className="bg-black/20 border-white/10 text-white cursor-pointer file:cursor-pointer file:text-zinc-300 file:bg-zinc-800 file:border-0 file:mr-4 file:px-4 file:py-2 file:rounded-md hover:file:bg-zinc-700"
                                                onChange={(e) => {
                                                    if (e.target.files && e.target.files[0]) {
                                                        setProofFile(e.target.files[0]);
                                                    }
                                                }}
                                            />
                                        </div>

                                        <Button
                                            className="w-full bg-emerald-600 hover:bg-emerald-700"
                                            onClick={handleDeposit}
                                            disabled={submitting || !proofFile || !depositAmount}
                                        >
                                            {submitting ? 'Submitting...' : 'Confirm Deposit'}
                                        </Button>
                                    </div>
                                ) : (
                                    <Button
                                        className="w-full bg-emerald-600 hover:bg-emerald-700"
                                        onClick={handleGenerateAddress}
                                        disabled={generatingAddress || !depositAmount || Number(depositAmount) <= 0}
                                    >
                                        {generatingAddress ? 'Generating...' : 'Generate Deposit Address'}
                                    </Button>
                                )}
                            </TabsContent>
                            <TabsContent value="withdraw" className="space-y-4 mt-4">
                                <div className="space-y-2">
                                    <Label className="text-zinc-300">Withdrawal Address</Label>
                                    <Input
                                        placeholder="TRC20 Address"
                                        className="bg-black/20 border-white/10 text-white"
                                        value={withdrawalAddress}
                                        onChange={(e) => setWithdrawalAddress(e.target.value)}
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-zinc-300">Amount</Label>
                                    <Input
                                        placeholder="Min $50.00"
                                        className="bg-black/20 border-white/10 text-white"
                                        type="number"
                                        value={withdrawalAmount}
                                        onChange={(e) => setWithdrawalAmount(e.target.value)}
                                    />
                                </div>
                                <Button
                                    variant="destructive"
                                    className="w-full"
                                    onClick={handleWithdrawal}
                                    disabled={submitting || Number(withdrawalAmount) < 10 || !withdrawalAddress}
                                >
                                    {submitting ? 'Processing...' : 'Request Withdrawal'}
                                </Button>
                            </TabsContent>
                        </Tabs>
                    </CardContent>
                </Card>
            </div>

            {/* Recent Transactions */}
            <Card className="glass-card border-white/5">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-white">
                        <HistoryIcon className="w-5 h-5" /> Recent Transactions
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow className="border-white/5 hover:bg-transparent">
                                <TableHead className="text-zinc-400">Type</TableHead>
                                <TableHead className="text-zinc-400">Description</TableHead>
                                <TableHead className="text-zinc-400">Date</TableHead>
                                <TableHead className="text-right text-zinc-400">Amount</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {transactions.map((tx) => (
                                <TableRow key={tx.id} className="border-white/5 hover:bg-white/5">
                                    <TableCell>
                                        <Badge variant={tx.type.toLowerCase() === 'credit' ? 'secondary' : 'destructive'}
                                            className={`${tx.type.toLowerCase() === 'credit' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
                                            {tx.type.toUpperCase()}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="font-medium text-zinc-300">{tx.description}</TableCell>
                                    <TableCell className="text-zinc-500">{new Date(tx.created_at).toLocaleDateString()}</TableCell>
                                    <TableCell className={`text-right font-bold ${tx.type.toLowerCase() === 'credit' ? 'text-emerald-400' : 'text-white'}`}>
                                        {tx.type.toLowerCase() === 'credit' ? '+' : '-'}${Number(tx.amount).toFixed(2)}
                                    </TableCell>
                                </TableRow>
                            ))}
                            {transactions.length === 0 && !loading && (
                                <TableRow>
                                    <TableCell colSpan={4} className="text-center py-8 text-zinc-500">
                                        No transactions found
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}
