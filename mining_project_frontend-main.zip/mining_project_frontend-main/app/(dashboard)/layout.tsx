import { Sidebar } from "@/components/dashboard/Sidebar";
import { Topbar } from "@/components/dashboard/Topbar";

export default function DashboardLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <div className="flex min-h-screen bg-[#020617]"> {/* Force dark background */}
            {/* Fixed Background Pattern */}
            <div className="fixed inset-0 z-0 pointer-events-none">
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-violet-900/10 rounded-full blur-[100px]" />
                <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-indigo-900/10 rounded-full blur-[100px]" />
                <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-[0.03]" />
            </div>

            <div className="hidden lg:block w-64 fixed inset-y-0 z-50">
                <Sidebar />
            </div>

            <div className="lg:pl-64 flex-1 flex flex-col min-h-screen relative z-10 transition-all duration-300">
                <Topbar />
                <main className="flex-1 p-6 lg:p-10">
                    <div className="space-y-6">
                        {children}
                    </div>
                </main>
            </div>
        </div>
    );
}
