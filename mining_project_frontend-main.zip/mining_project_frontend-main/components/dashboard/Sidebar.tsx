"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuthStore } from "@/store/authStore";
import { cn } from "@/lib/utils";
import {
    LayoutDashboard,
    Wallet,
    History,
    ShoppingBag,
    LogOut,
    User,
    Settings,
    ShieldCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";

const navItems = [
    { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
    { href: "/dashboard/wallet", label: "Wallet", icon: Wallet },
    { href: "/dashboard/history", label: "My Mining", icon: History },
    { href: "/products", label: "Buy Contracts", icon: ShoppingBag },
    { href: "/dashboard/profile", label: "Profile", icon: User },
];

export function Sidebar() {
    const pathname = usePathname();
    const { logout, isAdmin } = useAuthStore();

    return (
        <div className="flex bg-black/40 h-full w-64 flex-col border-r border-white/10 glass-card rounded-none">
            <div className="flex h-16 items-center px-6 border-b border-white/5">
                <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-violet-600 to-indigo-600 flex items-center justify-center">
                        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    </div>
                    <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-white/70">MineFi</span>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto py-6 px-3 space-y-1">
                {navItems.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                        <Link key={item.href} href={item.href}>
                            <Button
                                variant="ghost"
                                className={cn(
                                    "w-full justify-start gap-3 h-11 text-base font-normal",
                                    isActive
                                        ? "bg-violet-600/10 text-violet-400 border border-violet-600/20 shadow-sm shadow-violet-900/20"
                                        : "text-zinc-400 hover:text-white hover:bg-white/5"
                                )}
                            >
                                <item.icon className="w-5 h-5" />
                                {item.label}
                            </Button>
                        </Link>
                    );
                })}

                {isAdmin() && (
                    <div className="pt-4 mt-4 border-t border-white/5 space-y-1">
                        <p className="px-3 text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2">Admin</p>
                        <Link href="/admin">
                            <Button
                                variant="ghost"
                                className={cn(
                                    "w-full justify-start gap-3 h-11 text-base font-normal text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10"
                                )}
                            >
                                <ShieldCheck className="w-5 h-5" />
                                Admin Dashboard
                            </Button>
                        </Link>
                    </div>
                )}
            </div>

            <div className="p-4 border-t border-white/5">
                <Button
                    variant="ghost"
                    className="w-full justify-start gap-3 text-red-400 hover:text-red-300 hover:bg-red-900/10"
                    onClick={() => logout()}
                >
                    <LogOut className="w-5 h-5" />
                    Sign Out
                </Button>
            </div>
        </div>
    );
}
