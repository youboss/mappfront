"use client";

import { useAuthStore } from "@/store/authStore";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";
// import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"; // Will implement Mobile Sheet later
import { Sidebar } from "./Sidebar";
import Image from "next/image";

export function Topbar() {
    const user = useAuthStore((state) => state.user);

    return (
        <header className="h-16 border-b border-white/5 bg-black/20 backdrop-blur-md flex items-center justify-between px-6 sticky top-0 z-50">
            <div className="lg:hidden">
                {/* Mobile Menu Trigger Placeholder - Access Sidebar via Sheet later */}
                <Button variant="ghost" size="icon">
                    <Menu className="w-5 h-5 text-zinc-400" />
                </Button>
            </div>

            <div className="flex-1 flex justify-end items-center gap-4">
                <div className="flex items-center gap-3 pl-4 border-l border-white/10">
                    <div className="text-right hidden md:block">
                        <div className="text-sm font-medium text-white">{user?.name}</div>
                        <div className="text-xs text-zinc-500 capitalize">{user?.roles?.[0]?.name || "User"}</div>
                    </div>
                    <div className="w-8 h-8 rounded-full bg-zinc-800 border border-white/10 flex items-center justify-center overflow-hidden">
                        {/* Placeholder for Avatar */}
                        <span className="text-xs font-bold text-zinc-400">{user?.name?.charAt(0)}</span>
                    </div>
                </div>
            </div>
        </header>
    );
}
