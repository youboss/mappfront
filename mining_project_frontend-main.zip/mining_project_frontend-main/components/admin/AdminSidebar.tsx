"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuthStore } from "@/store/authStore";
import { cn } from "@/lib/utils";
import {
    LayoutDashboard,
    Users,
    Package,
    CreditCard,
    LogOut,
    ShieldAlert
} from "lucide-react";
import { Button } from "@/components/ui/button";

const navItems = [
    { href: "/admin", label: "Overview", icon: LayoutDashboard },
    { href: "/admin/products", label: "Products", icon: Package },
    { href: "/admin/users", label: "Users", icon: Users },
    { href: "/admin/requests", label: "Fund Requests", icon: CreditCard },
];

export function AdminSidebar() {
    const pathname = usePathname();
    const { logout, user } = useAuthStore();

    return (
        <div className="flex bg-[#0a0a0a]/95 h-full w-64 flex-col border-r border-white/5 backdrop-blur-xl">
            <div className="flex h-20 items-center px-6 border-b border-white/5 bg-gradient-to-b from-red-500/5 to-transparent">
                <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-red-500 to-rose-600 flex items-center justify-center shadow-lg shadow-red-900/20">
                        <ShieldAlert className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex flex-col">
                        <span className="text-sm font-bold text-white tracking-wider uppercase">Admin Console</span>
                        <span className="text-[10px] text-red-400/80 font-medium tracking-widest uppercase">Secure Access</span>
                    </div>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto py-8 px-4 space-y-2">
                <p className="px-2 text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] mb-4">Main Menu</p>
                {navItems.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                        <Link key={item.href} href={item.href}>
                            <Button
                                variant="ghost"
                                className={cn(
                                    "w-full justify-start gap-3 h-12 text-sm font-medium transition-all duration-300 rounded-xl px-4",
                                    isActive
                                        ? "bg-red-500/10 text-red-500 border border-red-500/20 shadow-sm shadow-red-500/5"
                                        : "text-zinc-400 hover:text-white hover:bg-white/5"
                                )}
                            >
                                <item.icon className={cn("w-5 h-5 transition-colors", isActive ? "text-red-500" : "text-zinc-500")} />
                                {item.label}
                                {isActive && (
                                    <div className="ml-auto w-1 h-1 rounded-full bg-red-500 shadow-sm shadow-red-500" />
                                )}
                            </Button>
                        </Link>
                    );
                })}
            </div>

            <div className="p-4 border-t border-white/5 bg-black/20">
                <div className="mb-6 px-2 py-3 rounded-2xl bg-white/5 border border-white/5 overflow-hidden relative">
                    <div className="absolute top-0 right-0 w-12 h-12 bg-emerald-500/10 rounded-full blur-xl" />
                    <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">System Health</div>
                    <div className="flex items-center gap-2">
                        <div className="relative">
                            <span className="relative flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                            </span>
                        </div>
                        <span className="text-xs font-medium text-emerald-400">All Systems Normal</span>
                    </div>
                </div>

                <div className="flex items-center gap-3 px-2 mb-4">
                    <div className="w-8 h-8 rounded-full bg-zinc-800 border border-white/10 flex items-center justify-center uppercase text-xs font-bold text-zinc-300">
                        {user?.name?.[0] || 'A'}
                    </div>
                    <div className="flex flex-col overflow-hidden">
                        <span className="text-xs font-medium text-white truncate">{user?.name || 'Administrator'}</span>
                        <span className="text-[10px] text-zinc-500 truncate">{user?.email}</span>
                    </div>
                </div>

                <Button
                    variant="ghost"
                    className="w-full justify-start gap-3 h-11 text-sm font-medium text-zinc-400 hover:text-white hover:bg-white/5 rounded-xl transition-all"
                    onClick={() => logout()}
                >
                    <LogOut className="w-4 h-4" />
                    Secure Logout
                </Button>
            </div>
        </div>
    );
}
