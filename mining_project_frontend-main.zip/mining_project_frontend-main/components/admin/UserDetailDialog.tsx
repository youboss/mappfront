"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Shield, Calendar, MapPin, Activity } from "lucide-react";
import apiClient from "@/lib/api";
import { Badge } from "@/components/ui/badge";

interface LoginActivity {
    id: number;
    ip_address: string;
    user_agent: string;
    created_at: string;
    status: string;
}

interface WalletTransaction {
    id: number;
    type: string;
    amount: string;
    description: string;
    created_at: string;
}

interface UserDetail {
    id: number;
    name: string;
    email: string;
    status: string;
    created_at: string;
    roles: { name: string }[];
    login_activities: LoginActivity[];
    wallet_transactions: WalletTransaction[];
}

interface UserDetailDialogProps {
    userId: number | null;
    open: boolean;
    onOpenChange: (open: boolean) => void;
}

export function UserDetailDialog({ userId, open, onOpenChange }: UserDetailDialogProps) {
    const [user, setUser] = useState<UserDetail | null>(null);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (userId && open) {
            const fetchUser = async () => {
                setLoading(true);
                try {
                    const response = await apiClient.get(`/admin/users/${userId}`);
                    if (response.data.success) {
                        setUser(response.data.data);
                    }
                } catch (error) {
                    console.error("Failed to fetch user details:", error);
                } finally {
                    setLoading(false);
                }
            };
            fetchUser();
        } else {
            setUser(null);
        }
    }, [userId, open]);

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[700px] bg-zinc-950 border-zinc-800 text-white max-h-[85vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>User Details</DialogTitle>
                    <DialogDescription>
                        View comprehensive user activity and history.
                    </DialogDescription>
                </DialogHeader>

                {loading ? (
                    <div className="flex justify-center py-10">
                        <Loader2 className="animate-spin text-zinc-500" />
                    </div>
                ) : user ? (
                    <div className="space-y-6">
                        {/* Header Info */}
                        <div className="flex items-start justify-between border-b border-zinc-800 pb-4">
                            <div>
                                <h3 className="text-xl font-bold">{user.name}</h3>
                                <p className="text-zinc-400">{user.email}</p>
                            </div>
                            <div className="flex gap-2">
                                <Badge variant="outline" className="border-zinc-700 text-zinc-300 capitalize">
                                    {user.status}
                                </Badge>
                                <Badge variant="outline" className="border-blue-500/20 text-blue-400 capitalize">
                                    {user.roles[0]?.name || 'User'}
                                </Badge>
                            </div>
                        </div>

                        {/* Stats Grid */}
                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-4 rounded-lg bg-zinc-900/50 border border-zinc-800">
                                <span className="text-xs text-zinc-500 flex items-center gap-1">
                                    <Calendar className="w-3 h-3" /> Joined
                                </span>
                                <div className="text-lg font-medium">{new Date(user.created_at).toLocaleDateString()}</div>
                            </div>
                            <div className="p-4 rounded-lg bg-zinc-900/50 border border-zinc-800">
                                <span className="text-xs text-zinc-500 flex items-center gap-1">
                                    <Activity className="w-3 h-3" /> Last Activity
                                </span>
                                <div className="text-lg font-medium">
                                    {user.login_activities?.[0] ? new Date(user.login_activities[0].created_at).toLocaleDateString() : 'N/A'}
                                </div>
                            </div>
                        </div>

                        <Tabs defaultValue="logins" className="w-full">
                            <TabsList className="bg-zinc-900 border border-zinc-800">
                                <TabsTrigger value="logins" className="data-[state=active]:bg-zinc-800 data-[state=active]:text-white text-zinc-400">Login History</TabsTrigger>
                                <TabsTrigger value="transactions" className="data-[state=active]:bg-zinc-800 data-[state=active]:text-white text-zinc-400">Transactions</TabsTrigger>
                            </TabsList>
                            <TabsContent value="logins" className="mt-4">
                                <div className="space-y-2">
                                    {user.login_activities?.length === 0 ? (
                                        <p className="text-center text-zinc-500 py-4">No login history found.</p>
                                    ) : (
                                        user.login_activities?.map((log) => (
                                            <div key={log.id} className="flex justify-between items-center p-3 rounded bg-zinc-900/30 text-sm border border-zinc-800/50">
                                                <div>
                                                    <div className="text-zinc-300 font-mono text-xs">{log.ip_address}</div>
                                                    <div className="text-zinc-500 text-xs truncate max-w-[300px]" title={log.user_agent}>{log.user_agent}</div>
                                                </div>
                                                <div className="text-right">
                                                    <div className="text-zinc-400">{new Date(log.created_at).toLocaleString()}</div>
                                                    <span className="text-emerald-500 text-xs capitalize">{log.status}</span>
                                                </div>
                                            </div>
                                        ))
                                    )}
                                </div>
                            </TabsContent>
                            <TabsContent value="transactions" className="mt-4">
                                <div className="space-y-2">
                                    {user.wallet_transactions?.length === 0 ? (
                                        <p className="text-center text-zinc-500 py-4">No transaction history found.</p>
                                    ) : (
                                        user.wallet_transactions?.map((tx) => (
                                            <div key={tx.id} className="flex justify-between items-center p-3 rounded bg-zinc-900/30 text-sm border border-zinc-800/50">
                                                <div>
                                                    <div className="text-zinc-300 font-medium">{tx.description}</div>
                                                    <span className={`text-xs ${tx.type === 'credit' ? 'text-emerald-500' : 'text-red-500'} capitalize`}>
                                                        {tx.type}
                                                    </span>
                                                </div>
                                                <div className="text-right">
                                                    <div className={`font-bold ${tx.type === 'credit' ? 'text-emerald-400' : 'text-red-400'}`}>
                                                        {tx.type === 'credit' ? '+' : '-'}${tx.amount}
                                                    </div>
                                                    <div className="text-zinc-500 text-xs">{new Date(tx.created_at).toLocaleDateString()}</div>
                                                </div>
                                            </div>
                                        ))
                                    )}
                                </div>
                            </TabsContent>
                        </Tabs>
                    </div>
                ) : (
                    <div className="text-center py-10 text-red-400">Failed to load user data.</div>
                )}
            </DialogContent>
        </Dialog>
    );
}
