"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Upload } from "lucide-react";
import apiClient from "@/lib/api";

interface Product {
    id: number;
    name: string;
    description: string | null;
    price: number;
    image_url: string | null;
    status: string;
}

interface ProductDialogProps {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    productToEdit?: Product | null;
    onProductSaved: () => void;
}

export function ProductDialog({ open, onOpenChange, productToEdit, onProductSaved }: ProductDialogProps) {
    const [name, setName] = useState("");
    const [description, setDescription] = useState("");
    const [price, setPrice] = useState("");
    const [image, setImage] = useState<File | null>(null);
    const [status, setStatus] = useState("active");
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (productToEdit) {
            setName(productToEdit.name);
            setDescription(productToEdit.description || "");
            setPrice(productToEdit.price.toString());
            setStatus(productToEdit.status || "active");
        } else {
            setName("");
            setDescription("");
            setPrice("");
            setStatus("active");
        }
        setImage(null);
    }, [productToEdit, open]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        try {
            const formData = new FormData();
            formData.append("name", name);
            formData.append("description", description);
            formData.append("price", price);
            formData.append("status", status);
            if (image) {
                formData.append("image", image);
            }

            if (productToEdit) {
                // Determine if we need to use a different method or route for update with file
                // Laravel resource update handles PUT/PATCH, but for files usually POST with _method=PUT is safer
                formData.append("_method", "POST"); // Or handle in backend
                await apiClient.post(`/admin/products/${productToEdit.id}`, formData, {
                    headers: { "Content-Type": "multipart/form-data" },
                });
            } else {
                await apiClient.post("/admin/products", formData, {
                    headers: { "Content-Type": "multipart/form-data" },
                });
            }

            onProductSaved();
            onOpenChange(false);
        } catch (error) {
            console.error("Failed to save product:", error);
            // Handle error (toast, etc.)
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[425px] bg-zinc-950 border-zinc-800 text-white">
                <DialogHeader>
                    <DialogTitle>{productToEdit ? "Edit Product" : "Add Product"}</DialogTitle>
                    <DialogDescription>
                        {productToEdit ? "Update product details." : "Add a new product to the catalog."}
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit}>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="name" className="text-right text-zinc-400">
                                Name
                            </Label>
                            <Input
                                id="name"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="col-span-3 bg-zinc-900 border-zinc-800 text-white"
                                required
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="description" className="text-right text-zinc-400">
                                Desc
                            </Label>
                            <Textarea
                                id="description"
                                value={description}
                                onChange={(e) => setDescription(e.target.value)}
                                className="col-span-3 bg-zinc-900 border-zinc-800 text-white"
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="price" className="text-right text-zinc-400">
                                Price
                            </Label>
                            <Input
                                id="price"
                                type="number"
                                step="0.01"
                                value={price}
                                onChange={(e) => setPrice(e.target.value)}
                                className="col-span-3 bg-zinc-900 border-zinc-800 text-white"
                                required
                            />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="image" className="text-right text-zinc-400">
                                Image
                            </Label>
                            <div className="col-span-3">
                                <Input
                                    id="image"
                                    type="file"
                                    accept="image/*"
                                    onChange={(e) => setImage(e.target.files?.[0] || null)}
                                    className="bg-zinc-900 border-zinc-800 text-white file:text-zinc-400"
                                />
                            </div>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="ghost" onClick={() => onOpenChange(false)} className="text-zinc-400">
                            Cancel
                        </Button>
                        <Button type="submit" disabled={loading} className="bg-violet-600 hover:bg-violet-700 text-white">
                            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            {productToEdit ? "Update" : "Create"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
