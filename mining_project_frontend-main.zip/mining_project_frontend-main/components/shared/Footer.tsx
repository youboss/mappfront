export default function Footer() {
    return (
        <footer className="border-t border-white/5 bg-black/40 backdrop-blur-lg">
            <div className="container mx-auto px-4 py-8 md:py-12">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                    <div className="col-span-2">
                        <h3 className="text-lg font-bold text-white mb-4">MineFi</h3>
                        <p className="text-sm text-muted-foreground max-w-xs">
                            The premium platform for sustainable crypto mining investments. Join thousands of investors today.
                        </p>
                    </div>
                    <div>
                        <h4 className="font-semibold text-white mb-4">Platform</h4>
                        <ul className="space-y-2 text-sm text-muted-foreground">
                            <li><a href="#" className="hover:text-white transition-colors">Investments</a></li>
                            <li><a href="#" className="hover:text-white transition-colors">Marketplace</a></li>
                            <li><a href="#" className="hover:text-white transition-colors">Security</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-semibold text-white mb-4">Company</h4>
                        <ul className="space-y-2 text-sm text-muted-foreground">
                            <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                            <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
                            <li><a href="#" className="hover:text-white transition-colors">Privacy</a></li>
                        </ul>
                    </div>
                </div>
                <div className="mt-12 pt-8 border-t border-white/5 text-center text-xs text-muted-foreground">
                    © {new Date().getFullYear()} MineFi. All rights reserved.
                </div>
            </div>
        </footer>
    );
}
