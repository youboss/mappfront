"use client";
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactNode, useEffect, useState } from 'react';
import { Toaster } from 'sonner';
import { useAuthStore } from '@/store/authStore';
import apiClient from '@/lib/api';
import { Loader2 } from 'lucide-react';

export default function Providers({ children }: { children: ReactNode }) {
    const [queryClient] = useState(() => new QueryClient({
        defaultOptions: {
            queries: {
                staleTime: 60 * 1000,
                retry: 1,
            },
        },
    }));

    const { setAuth, isAuthenticated } = useAuthStore();
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const initAuth = async () => {
            // Clean up legacy storage
            if (typeof window !== 'undefined') {
                localStorage.removeItem('auth_token');
                localStorage.removeItem('auth-storage');
            }

            try {
                // Try to get user data from the session
                const res = await apiClient.get('/user');
                if (res.data.success) {
                    setAuth(res.data.data);
                }
            } catch (error) {
                // Not authenticated, that's fine for public routes
                console.log('Session check: Not authenticated');
            } finally {
                setLoading(false);
            }
        };

        initAuth();
    }, [setAuth]);

    if (loading) {
        return (
            <div className="h-screen w-full flex items-center justify-center bg-black">
                <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
            </div>
        );
    }

    return (
        <QueryClientProvider client={queryClient}>
            {children}
            <Toaster richColors position="top-center" />
        </QueryClientProvider>
    );
}
