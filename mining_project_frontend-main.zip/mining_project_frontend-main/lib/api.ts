import axios from 'axios';

const apiDomain = process.env.NEXT_PUBLIC_API_DOMAIN || 'http://localhost:8000';
const baseURL = `${apiDomain}/api`;

export const getCsrfCookie = () => axios.get(`${apiDomain}/sanctum/csrf-cookie`, { withCredentials: true });

const apiClient = axios.create({
  baseURL,
  withCredentials: true,
  withXSRFToken: true, // Required for secure CSRF handling in newer Axios versions
  xsrfCookieName: 'XSRF-TOKEN',
  xsrfHeaderName: 'X-XSRF-TOKEN',
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  },
});

apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // Logic to handle session expiry
      if (typeof window !== 'undefined' && !window.location.pathname.startsWith('/login')) {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export default apiClient;
